import os, zipfile, json

artifacts_dir = '/app/applet/.aistudio/artifacts/brain/1e85614a-1a36-40c9-9d9d-04bf0651ef2e'
os.makedirs(artifacts_dir, exist_ok=True)

# 1. Update ZIP
zip_path = os.path.join(artifacts_dir, 'kaderbot_projet_complet.zip')
exclude_dirs = {'.git', 'node_modules', '.aistudio'}

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
        for file in files:
            if file.startswith('.'): continue
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, '.')
            zipf.write(full_path, rel_path)

print('Fresh ZIP regenerated with size:', os.path.getsize(zip_path))

# 2. Update Markdown
target_path = os.path.join(artifacts_dir, 'kaderbot_code_source_complet.md')

files_to_bundle = [
    ('package.json', 'json'),
    ('vite.config.ts', 'typescript'),
    ('tsconfig.json', 'json'),
    ('index.html', 'html'),
    ('src/index.css', 'css'),
    ('src/main.tsx', 'typescript'),
    ('src/types/kaderbot.ts', 'typescript'),
    ('src/core/cognitiveEngine.ts', 'typescript'),
    ('src/services/apiService.ts', 'typescript'),
    ('src/App.tsx', 'typescript'),
    ('src/components/Header.tsx', 'typescript'),
    ('src/components/ChatTab.tsx', 'typescript'),
    ('src/components/KnowledgeGraphTab.tsx', 'typescript'),
    ('src/components/RulesTab.tsx', 'typescript'),
    ('src/components/ToolsTab.tsx', 'typescript'),
    ('src/components/SessionsTab.tsx', 'typescript'),
    ('src/components/SettingsModal.tsx', 'typescript'),
    ('src/components/ActionMenuModal.tsx', 'typescript'),
    ('src/hooks/usePWAInstall.ts', 'typescript'),
    ('server.ts', 'typescript'),
]

header = """# KADERBOT — Code Source Complet & Guide de Déploiement

Ce document contient **l'intégralité du code source mis à jour** du projet **KADERBOT**, incluant les 3 dernières améliorations majeures :

1. **Clé API Gemini dans les Paramètres Admin (`SettingsModal.tsx`)** :
   - Champ de saisie sécurisé pour la clé API Gemini avec testeur de connexion instantané (`/api/gemini/test`).
   - Le serveur (`server.ts`) utilise en priorité cette clé personnalisée si fournie, sinon il bascule automatiquement sur la variable d'environnement `GEMINI_API_KEY`.

2. **Boutons de certitude masqués en Mode Public (`ChatTab.tsx`)** :
   - Les boutons d'évaluation "Exact (+0.1)" et "Inexact (-0.15)" sous les réponses du bot sont désormais strictement réservés à l'administrateur (`?admin=true`).
   - L'interface publique reste ainsi épurée, propre et orientée utilisateur final.

3. **Verrouillage du défilement & Zone de saisie fixe sur Mobile** :
   - La zone de saisie (champ texte, micro de dictée vocale, bouton effacer et bouton envoyer) reste désormais en permanence fixée et visible en bas de l'écran sur mobile (`h-[100dvh]`, `flex-shrink-0`).
   - Seule la liste des messages défile de manière fluide (`overflow-y-auto min-h-0 overscroll-contain`), empêchant la page entière de glisser ou de masquer la barre de chat.

---

## 🛠 Script Python de Réextraction Automatique (`unbundle.py`)

Si vous téléchargez ce document en tant que fichier texte et souhaitez recréer l'arborescence des dossiers et fichiers :

```python
# unbundle.py
import os, re

with open('kaderbot_code_source_complet.md', 'r', encoding='utf-8') as f:
    text = f.read()

pattern = re.compile(r'### Fichier : `([^`]+)`\\n\\n```[a-zA-Z0-9_-]*\\n(.*?)```\\n\\n---', re.DOTALL)
matches = pattern.findall(text)

print(f'Extraction de {len(matches)} fichiers...')
for rel_path, content in matches:
    os.makedirs(os.path.dirname(rel_path), exist_ok=True)
    with open(rel_path, 'w', encoding='utf-8') as out:
        out.write(content)
    print(f'-> {rel_path}')

print('Extraction terminée avec succès !')
```

---

## 📂 Code Source Intégral du Projet

"""

with open(target_path, 'w', encoding='utf-8') as out:
    out.write(header)
    for rel_path, lang in files_to_bundle:
        if os.path.exists(rel_path):
            with open(rel_path, 'r', encoding='utf-8') as src:
                code = src.read()
            out.write(f'### Fichier : `{rel_path}`\n\n```{lang}\n{code}\n```\n\n---\n\n')
            print(f'Bundled {rel_path}')
        else:
            print(f'Warning: {rel_path} not found')

metadata_path = target_path + '.metadata.json'
metadata = {
    "Summary": "Code source complet de l'application web KaderBot incluant la clé API Gemini configurable en Admin, les boutons de confiance réservés à l'admin, le défilement mobile verrouillé avec zone de saisie fixe, et l'archive ZIP prête au téléchargement.",
    "UserFacing": True,
    "RequestFeedback": False
}
with open(metadata_path, 'w', encoding='utf-8') as meta:
    json.dump(metadata, meta, indent=2)

print('Markdown artifact refreshed successfully!')
