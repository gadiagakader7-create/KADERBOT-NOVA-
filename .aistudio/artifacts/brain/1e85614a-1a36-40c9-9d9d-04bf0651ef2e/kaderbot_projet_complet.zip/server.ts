import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { randomUUID, timingSafeEqual } from 'crypto';
import { GoogleGenAI } from '@google/genai';
import { AGENT_TOOLS, TOOL_POLICIES } from './src/agent/toolRegistry';
import type { PendingAgentAction } from './src/types/agent';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

const portArgIndex = process.argv.indexOf('--port');
const cliPort = portArgIndex !== -1 && process.argv[portArgIndex + 1] ? Number(process.argv[portArgIndex + 1]) : NaN;
const PORT = Number(process.env.PORT) || (!Number.isNaN(cliPort) && cliPort > 0 ? cliPort : 3000);

const hostArgIndex = process.argv.indexOf('--host');
const cliHost = hostArgIndex !== -1 && process.argv[hostArgIndex + 1] ? process.argv[hostArgIndex + 1] : undefined;
const HOST = process.env.HOST || cliHost || '0.0.0.0';

app.use(express.json({ limit: '10mb' }));

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
const MEMORY_FILE = path.join(DATA_DIR, 'kaderbot_storage.json');
const BRAVE_USAGE_FILE = path.join(DATA_DIR, 'brave_usage.json');
const NOTES_FILE = path.join(DATA_DIR, 'kaderbot_notes.json');
const ACTION_LOG_FILE = path.join(DATA_DIR, 'kaderbot_action_logs.json');
const EVENTS_FILE = path.join(DATA_DIR, 'kaderbot_events.json');

// === 1. CONSTANTES ET SÉCURITÉ DE L'AGENT ===
const BRAVE_API_KEY = process.env.BRAVE_SEARCH_API_KEY?.trim() || '';
const ADMIN_TOKEN = process.env.ADMIN_TOKEN?.trim() || '';
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN?.trim() || '';
const TELEGRAM_ALLOWED_CHAT_IDS = new Set(
  (process.env.TELEGRAM_ALLOWED_CHAT_IDS || '')
    .split(',')
    .map(value => value.trim())
    .filter(Boolean)
);
const MAX_AGENT_ITERATIONS = 4;
const MAX_BRAVE_CALLS_PER_DAY = 100;
const PENDING_ACTION_TTL_MS = 5 * 60 * 1000;
const AGENT_RATE_LIMIT_WINDOW_MS = 60 * 1000;
const AGENT_RATE_LIMIT_MAX = 10;


const pendingAgentActions = new Map<string, PendingAgentAction>();
const agentRateLimits = new Map<string, { startedAt: number; count: number }>();

function checkAgentRateLimit(req: express.Request): boolean {
  const key = req.ip || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const current = agentRateLimits.get(key);
  if (!current || now - current.startedAt >= AGENT_RATE_LIMIT_WINDOW_MS) {
    agentRateLimits.set(key, { startedAt: now, count: 1 });
    return true;
  }
  if (current.count >= AGENT_RATE_LIMIT_MAX) return false;
  current.count += 1;
  return true;
}

function validateToolArguments(tool: string, args: Record<string, unknown>): string | null {
  const isNonEmptyString = (value: unknown): value is string => typeof value === 'string' && value.trim().length > 0;
  const policy = TOOL_POLICIES[tool];
  if (!policy) return `Outil non autorisé : ${tool}`;

  if (tool === 'search_web' || tool === 'search_news' || tool === 'memo_lookup') {
    const key = tool === 'memo_lookup' ? 'sujet' : 'query';
    if (!isNonEmptyString(args[key]) || String(args[key]).length > 500) return `Paramètre ${key} invalide.`;
  }
  if (tool === 'search_notes' && (!isNonEmptyString(args.query) || String(args.query).length > 500)) return 'Paramètre query invalide.';
  if (tool === 'list_events') {
    if (!isNonEmptyString(args.start_iso) || !isNonEmptyString(args.end_iso)) return 'Période de recherche requise.';
    if (Number.isNaN(Date.parse(String(args.start_iso))) || Number.isNaN(Date.parse(String(args.end_iso)))) return 'Dates ISO invalides.';
  }
  if (tool === 'create_event') {
    if (!isNonEmptyString(args.title) || !isNonEmptyString(args.start_iso) || !isNonEmptyString(args.end_iso)) return 'Titre et dates requis pour l’événement.';
    const start = Date.parse(String(args.start_iso));
    const end = Date.parse(String(args.end_iso));
    if (Number.isNaN(start) || Number.isNaN(end) || end <= start) return 'Période de l’événement invalide.';
    if (String(args.title).length > 200) return 'Titre d’événement trop long.';
  }
  if (tool === 'open_url' && (!isNonEmptyString(args.url) || String(args.url).length > 2048)) return 'Paramètre url invalide.';
  if (tool === 'memo_store' && (!isNonEmptyString(args.sujet) || !isNonEmptyString(args.definition))) return 'Sujet et définition requis.';
  if (tool === 'link_concepts' && (!isNonEmptyString(args.source) || !isNonEmptyString(args.cible))) return 'Source et cible requises.';
  if (tool === 'ask_user' && (!isNonEmptyString(args.question) || String(args.question).length > 500)) return 'Question invalide.';

  if (tool === 'create_note') {
    if (!isNonEmptyString(args.title) || !isNonEmptyString(args.body)) return 'Titre et contenu requis pour la note.';
    if (String(args.title).length > 200 || String(args.body).length > 10000) return 'Note trop longue.';
    if (args.tags !== undefined && (!Array.isArray(args.tags) || args.tags.some(tag => !isNonEmptyString(tag)))) return 'Tags invalides.';
  }

  if (tool === 'send_message') {
    if (!['sms', 'telegram', 'whatsapp'].includes(String(args.channel))) return 'Canal de message non autorisé.';
    if (!isNonEmptyString(args.target) || !isNonEmptyString(args.text)) return 'Destinataire et texte requis.';
    if (String(args.text).length > 4000) return 'Message trop long.';
    if ((args.channel === 'sms' || args.channel === 'telegram') && args.confirm !== true) return 'Confirmation explicite requise pour ce canal.';
  }
  return null;
}

function summarizePendingAction(tool: string, args: Record<string, unknown>): string {
  if (tool === 'memo_store') return `Mémoriser « ${String(args.sujet)} » : ${String(args.definition).slice(0, 180)}`;
  if (tool === 'link_concepts') return `Créer le lien « ${String(args.source)} » → « ${String(args.cible)} »`;
  if (tool === 'create_note') return `Créer la note « ${String(args.title)} »`;
  if (tool === 'send_message') return `Envoyer un message ${String(args.channel)} à ${String(args.target)} : « ${String(args.text).slice(0, 180)} »`;
  if (tool === 'create_event') return `Créer l’événement « ${String(args.title || 'sans titre')} »`;
  return `Autoriser l’action ${tool}`;
}

function createPendingAction(tool: string, args: Record<string, unknown>): PendingAgentAction {
  const expiresAt = new Date(Date.now() + PENDING_ACTION_TTL_MS).toISOString();
  const action: PendingAgentAction = {
    id: randomUUID(),
    tool,
    args,
    summary: summarizePendingAction(tool, args),
    risk: TOOL_POLICIES[tool]?.risk === 'external' ? 'external' : 'write',
    expiresAt,
  };
  pendingAgentActions.set(action.id, action);
  return action;
}

function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction): void {
  if (!ADMIN_TOKEN) {
    res.status(503).json({ error: 'Fonction d’administration indisponible : ADMIN_TOKEN n’est pas configuré.' });
    return;
  }

  const authorization = req.header('authorization') || '';
  const bearerToken = authorization.startsWith('Bearer ') ? authorization.slice(7).trim() : '';
  const providedToken = req.header('x-admin-token')?.trim() || bearerToken;
  const expected = Buffer.from(ADMIN_TOKEN);
  const provided = Buffer.from(providedToken);

  if (provided.length !== expected.length || !timingSafeEqual(provided, expected)) {
    res.status(401).json({ error: 'Jeton administrateur invalide ou manquant.' });
    return;
  }

  next();
}

// Compteur d'appels Brave en mémoire (Map avec date du jour), persisté dans data/brave_usage.json
const braveDailyUsage = new Map<string, number>();

function getTodayString(): string {
  return new Date().toISOString().slice(0, 10);
}

function loadBraveUsage(): void {
  const today = getTodayString();
  try {
    if (fs.existsSync(BRAVE_USAGE_FILE)) {
      const data = JSON.parse(fs.readFileSync(BRAVE_USAGE_FILE, 'utf-8'));
      if (data && data.date === today && typeof data.count === 'number') {
        braveDailyUsage.set(today, data.count);
        return;
      }
    }
  } catch (err) {
    console.warn('Erreur lecture brave_usage.json:', err);
  }
  braveDailyUsage.set(today, 0);
}

function checkAndIncrementBraveQuota(): boolean {
  const today = getTodayString();
  if (!braveDailyUsage.has(today)) {
    loadBraveUsage();
  }
  const currentCount = braveDailyUsage.get(today) || 0;
  if (currentCount >= MAX_BRAVE_CALLS_PER_DAY) {
    return false; // Quota de recherche atteint pour aujourd'hui
  }
  const newCount = currentCount + 1;
  braveDailyUsage.set(today, newCount);
  try {
    fs.writeFileSync(
      BRAVE_USAGE_FILE,
      JSON.stringify({ date: today, count: newCount, updatedAt: new Date().toISOString() }, null, 2),
      'utf-8'
    );
  } catch (err) {
    console.warn('Erreur persistance brave_usage.json:', err);
  }
  return true;
}

// Initialisation au chargement
loadBraveUsage();

// Sécurité open_url : Liste blanche de domaines interdits (localhost, 127.0.0.1, adresses IP nues, *.internal, *.render.com)
function isUrlForbidden(urlStr: string): { forbidden: boolean; reason?: string } {
  try {
    const parsed = new URL(urlStr);
    const hostname = parsed.hostname.toLowerCase();

    // Protocole http ou https obligatoire
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return { forbidden: true, reason: 'Protocole non autorisé (seuls http et https sont acceptés).' };
    }

    // Localhost
    if (hostname === 'localhost' || hostname.endsWith('.localhost')) {
      return { forbidden: true, reason: 'Accès refusé : domaine localhost interdit.' };
    }

    // 127.0.0.1 ou boucle locale
    if (hostname === '127.0.0.1' || hostname === '0.0.0.0') {
      return { forbidden: true, reason: 'Accès refusé : adresse de bouclage locale interdite.' };
    }

    // Adresses IP nues (IPv4 standard ou IPv6)
    const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (ipv4Regex.test(hostname)) {
      return { forbidden: true, reason: 'Accès refusé : adresses IP directes non autorisées.' };
    }
    if (hostname.startsWith('[') && hostname.endsWith(']')) {
      return { forbidden: true, reason: 'Accès refusé : adresses IPv6 directes non autorisées.' };
    }

    // *.internal
    if (hostname === 'internal' || hostname.endsWith('.internal')) {
      return { forbidden: true, reason: 'Accès refusé : réseaux internes (*.internal) non autorisés.' };
    }

    // *.render.com
    if (hostname === 'render.com' || hostname.endsWith('.render.com')) {
      return { forbidden: true, reason: 'Accès refusé : domaine de plateforme d’hébergement (*.render.com) interdit.' };
    }

    return { forbidden: false };
  } catch (err: any) {
    return { forbidden: true, reason: `URL invalide : ${err.message}` };
  }
}

// Helpers de stockage mémoire cognitive locale
function readStorageFile(): {
  memoire: Record<string, any[]>;
  regles: Record<string, any[]>;
  liens: Record<string, string[]>;
  synonymes: Record<string, any>;
  sessions: string[];
} {
  if (fs.existsSync(MEMORY_FILE)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf-8'));
      return {
        memoire: parsed.memoire || {},
        regles: parsed.regles || {},
        liens: parsed.liens || {},
        synonymes: parsed.synonymes || {},
        sessions: Array.isArray(parsed.sessions) ? parsed.sessions : ['defaut'],
      };
    } catch (e) {
      console.warn('Erreur lecture kaderbot_storage.json:', e);
    }
  }
  return { memoire: {}, regles: {}, liens: {}, synonymes: {}, sessions: ['defaut'] };
}

function writeStorageFile(data: any): void {
  try {
    fs.writeFileSync(
      MEMORY_FILE,
      JSON.stringify(
        {
          memoire: data.memoire || {},
          regles: data.regles || {},
          liens: data.liens || {},
          synonymes: data.synonymes || {},
          sessions: Array.isArray(data.sessions) ? data.sessions : ['defaut'],
          updatedAt: new Date().toISOString(),
        },
        null,
        2
      ),
      'utf-8'
    );
  } catch (err) {
    console.error('Erreur écriture kaderbot_storage.json:', err);
  }
}

type KaderbotNote = {
  id: string;
  title: string;
  body: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
};

type AgentActionLog = {
  id: string;
  tool: string;
  args?: Record<string, unknown>;
  status: 'success' | 'error' | 'rejected' | 'expired';
  message?: string;
  createdAt: string;
};

type KaderbotEvent = {
  id: string;
  title: string;
  startIso: string;
  endIso: string;
  location?: string;
  description?: string;
  createdAt: string;
};

function readJsonArray<T>(filePath: string): T[] {
  try {
    if (!fs.existsSync(filePath)) return [];
    const parsed = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.warn(`Erreur lecture ${filePath}:`, err);
    return [];
  }
}

function writeJsonArray<T>(filePath: string, data: T[]): void {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
}

function appendActionLog(entry: Omit<AgentActionLog, 'id' | 'createdAt'>): void {
  try {
    const logs = readJsonArray<AgentActionLog>(ACTION_LOG_FILE);
    logs.push({ ...entry, id: randomUUID(), createdAt: new Date().toISOString() });
    writeJsonArray(ACTION_LOG_FILE, logs.slice(-500));
  } catch (err) {
    console.warn('Erreur écriture journal agentique:', err);
  }
}

// Helper to get GoogleGenAI client with explicit API Key (prevents Application Default Credentials lookup)
function createGeminiClient(apiKey: string): GoogleGenAI {
  return new GoogleGenAI({
    apiKey: apiKey.trim(),
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const DEFAULT_SYSTEM_PROMPT =
  'Tu es KADERBOT NOVA, un assistant IA expert et pédagogue. Tu réponds toujours en français.\n' +
  'RÈGLES DE FORMATAGE : Structure tes réponses avec du Markdown (sauts de ligne, listes à puces, gras).\n' +
  'RÈGLE DE LONGUEUR ABSOLUE : Ta réponse ne doit jamais dépasser 120 mots. Sois direct et synthétique. Si un sujet est vaste (comme l\'histoire d\'une invention), donne uniquement les 2 ou 3 points les plus importants, et termine en proposant à l\'utilisateur de préciser sa question pour plus de détails. Ne fais JAMAIS de réponse de plus de 4 paragraphes.';

// Helper to normalize and resolve Groq model IDs accurately (Catalogue Octobre 2026)
export function resolveGroqModel(requestedModel?: string): string {
  if (!requestedModel) return 'openai/gpt-oss-120b';
  const clean = requestedModel.trim().toLowerCase();

  // Si demande de 120b
  if (
    clean === 'openai/gpt-oss-120b' ||
    clean.includes('gpt-oss-120b') ||
    clean.includes('120b')
  ) {
    return 'openai/gpt-oss-120b';
  }

  // Si demande de 20b
  if (
    clean === 'openai/gpt-oss-20b' ||
    clean.includes('gpt-oss-20b') ||
    clean.includes('20b')
  ) {
    return 'openai/gpt-oss-20b';
  }

  // Toute demande de modèle inconnu ou déprécié → 'openai/gpt-oss-20b'
  return 'openai/gpt-oss-20b';
}

// Helper to call Groq with candidate fallback and clean error management
async function callGroqWithFallback(
  prompt: string,
  systemPrompt: string,
  apiKey: string,
  requestedModel = 'openai/gpt-oss-120b',
  history: Array<{ role: string; content: string }> = []
): Promise<{ text: string; actualModel: string }> {
  const primaryModel = resolveGroqModel(requestedModel);

  // Candidate models sur Groq : ces deux-là uniquement (Catalogue Octobre 2026)
  const candidateModels = Array.from(
    new Set([
      primaryModel,
      'openai/gpt-oss-120b',
      'openai/gpt-oss-20b',
    ])
  );

  const messages = [
    { role: 'system', content: systemPrompt },
    ...history,
    { role: 'user', content: prompt },
  ];

  let lastError = '';

  for (let idx = 0; idx < candidateModels.length; idx++) {
    const modelToTry = candidateModels[idx];
    const nextModel = candidateModels[idx + 1];

    try {
      const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey.trim()}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: modelToTry,
          messages,
          temperature: 0.7,
          max_tokens: 800,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const content = data.choices?.[0]?.message?.content?.trim() || '';
        return { text: content, actualModel: modelToTry };
      }

      const errData = await response.json().catch(() => null);
      const errMsg = errData?.error?.message || `HTTP ${response.status}`;
      lastError = errMsg;

      if (nextModel) {
        console.warn(`[BASCULE GROQ] Modèle "${modelToTry}" a échoué (cause: ${errMsg}). Bascule vers "${nextModel}"...`);
      } else {
        console.warn(`[BASCULE GROQ] Modèle "${modelToTry}" a échoué (cause: ${errMsg}). Aucun autre modèle Groq disponible.`);
      }

      // Si HTTP 401 (clé API invalide), inutile de réessayer les autres modèles avec la même clé
      if (response.status === 401) {
        break;
      }
    } catch (e: any) {
      lastError = e.message;
      if (nextModel) {
        console.warn(`[BASCULE GROQ] Exception sur "${modelToTry}" (cause: ${e.message}). Bascule vers "${nextModel}"...`);
      }
    }
  }

  throw new Error(`Groq: ${lastError}`);
}

// Helper to normalize and resolve OpenRouter model IDs accurately
export function resolveOpenRouterModel(requestedModel?: string): string {
  const defaultModel = 'meta-llama/llama-3.3-70b-instruct:free';
  if (!requestedModel) return defaultModel;
  let clean = requestedModel.trim();
  const lower = clean.toLowerCase();

  // Ne JAMAIS utiliser openai/gpt-oss-120b sur OpenRouter (réservé à Groq)
  if (lower.includes('gpt-oss') || lower.includes('gpt') || lower.includes('oss')) {
    return defaultModel;
  }

  // Normalisation des modèles
  if (lower.includes('llama-3.3-70b') || lower.includes('llama') || lower.includes('70b')) {
    return defaultModel;
  }
  if (lower.includes('qwen')) {
    return 'qwen/qwen3-coder:free';
  }
  if (lower.includes('deepseek') || lower.includes('r1')) {
    return 'deepseek/deepseek-r1:free';
  }

  // Le suffixe :free est obligatoire pour utiliser le quota gratuit
  if (!clean.endsWith(':free')) {
    clean = `${clean}:free`;
  }

  return clean;
}

// Helper to call OpenRouter with candidate fallback and clean quota management
async function callOpenRouterWithFallback(
  prompt: string,
  systemPrompt: string,
  apiKey: string,
  requestedModel = 'meta-llama/llama-3.3-70b-instruct:free',
  history: Array<{ role: string; content: string }> = []
): Promise<{ text: string; actualModel: string }> {
  const primaryModel = resolveOpenRouterModel(requestedModel);

  // Modèles candidats dans l'ordre strict demandé (sans jamais gpt-oss-120b)
  const candidateModels = Array.from(
    new Set([
      primaryModel,
      'meta-llama/llama-3.3-70b-instruct:free',
      'qwen/qwen3-coder:free',
      'deepseek/deepseek-r1:free',
    ])
  );

  const messages = [
    { role: 'system', content: systemPrompt },
    ...history,
    { role: 'user', content: prompt },
  ];

  let lastError = '';

  for (const modelToTry of candidateModels) {
    try {
      const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey.trim()}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': 'https://kaderbot.app',
          'X-Title': 'KADERBOT NOVA',
        },
        body: JSON.stringify({
          model: modelToTry,
          messages,
          temperature: 0.7,
          max_tokens: 800,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const content = data.choices?.[0]?.message?.content?.trim() || '';
        return { text: content, actualModel: modelToTry };
      }

      const errData = await response.json().catch(() => null);
      const errMsg = errData?.error?.message || `HTTP ${response.status}`;
      lastError = errMsg;

      // Si HTTP 429 (quota épuisé) ou 401 (clé invalide), NE PAS retenter avec un autre modèle :
      // lancer immédiatement l'erreur pour déclencher le fallback vers Gemini/Groq
      if (response.status === 429 || response.status === 401) {
        throw new Error('OpenRouter: quota épuisé ou clé invalide');
      }

      // Si HTTP 404 (modèle introuvable), passer au modèle suivant
      if (response.status === 404) {
        console.warn(`Modèle OpenRouter "${modelToTry}" non accessible (404), tentative avec modèle suivant...`);
        continue;
      }

      console.warn(`Erreur OpenRouter sur "${modelToTry}" (${response.status}: ${errMsg}), tentative avec modèle suivant...`);
    } catch (e: any) {
      if (e.message === 'OpenRouter: quota épuisé ou clé invalide') {
        throw e;
      }
      lastError = e.message;
    }
  }

  throw new Error(`OpenRouter: ${lastError || 'indisponible'}`);
}

// Helper to call Gemini with explicit API Key and direct REST fallback (Never uses Application Default Credentials)
async function callGeminiWithFallback(
  fullPrompt: string,
  systemInstruction?: string
): Promise<{ text: string; model: string }> {
  const geminiKey = process.env.GEMINI_API_KEY?.trim();
  if (!geminiKey) {
    throw new Error('Variable GEMINI_API_KEY non configurée sur le serveur. Veuillez définir votre clé API Gemini.');
  }

  const modelsToTry = ['gemini-3.8-flash', 'gemini-3.5-flash', 'gemini-flash-latest'];
  let lastError: any = null;

  // 1. Try with explicit GoogleGenAI client (with explicit apiKey)
  try {
    const aiClient = createGeminiClient(geminiKey);
    for (let i = 0; i < modelsToTry.length; i++) {
      const m = modelsToTry[i];
      const nextM = modelsToTry[i + 1];
      try {
        const response = await aiClient.models.generateContent({
          model: m,
          contents: fullPrompt,
          config: systemInstruction ? { systemInstruction } : undefined,
        });
        const text = response.text?.trim();
        if (text) {
          return { text, model: m };
        }
      } catch (err: any) {
        if (nextM) {
          console.warn(`[BASCULE GEMINI SDK] Modèle "${m}" a échoué (cause: ${err.message}). Bascule vers "${nextM}"...`);
        } else {
          console.warn(`[BASCULE GEMINI SDK] Modèle "${m}" a échoué (cause: ${err.message}). Bascule sur REST direct...`);
        }
        lastError = err;
      }
    }
  } catch (sdkInitErr: any) {
    console.warn('Erreur initialisation SDK Gemini, bascule sur REST direct:', sdkInitErr.message);
    lastError = sdkInitErr;
  }

  // 2. Direct REST Fallback (Simple API Key only, zero Google Cloud ADC or metadata)
  for (let i = 0; i < modelsToTry.length; i++) {
    const m = modelsToTry[i];
    const nextM = modelsToTry[i + 1];
    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${geminiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ parts: [{ text: fullPrompt }] }],
            systemInstruction: systemInstruction ? { parts: [{ text: systemInstruction }] } : undefined,
          }),
        }
      );

      if (response.ok) {
        const data = await response.json();
        const text = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
        if (text) {
          return { text, model: m };
        }
      } else {
        const errJson = await response.json().catch(() => null);
        const errMsg = errJson?.error?.message || `HTTP ${response.status}`;
        lastError = new Error(errMsg);
        if (nextM) {
          console.warn(`[BASCULE GEMINI REST] Modèle "${m}" a échoué (cause: ${errMsg}). Bascule vers "${nextM}"...`);
        } else {
          console.warn(`[BASCULE GEMINI REST] Modèle "${m}" a échoué (cause: ${errMsg}).`);
        }
      }
    } catch (restErr: any) {
      lastError = restErr;
      if (nextM) {
        console.warn(`[BASCULE GEMINI REST] Exception sur "${m}" (cause: ${restErr.message}). Bascule vers "${nextM}"...`);
      }
    }
  }

  throw lastError || new Error('Les modèles Gemini sont temporairement indisponibles.');
}

// 0. Gemini Connection Tester Endpoint (Uses process.env.GEMINI_API_KEY explicitly)
app.post('/api/gemini/test', async (req, res) => {
  try {
    const keyToUse = process.env.GEMINI_API_KEY?.trim() || req.body?.apiKey?.trim();
    if (!keyToUse) {
      return res.status(400).json({
        ok: false,
        error: 'Aucune variable GEMINI_API_KEY configurée sur le serveur.',
      });
    }

    const start = Date.now();
    const result = await callGeminiWithFallback('Réponds en un seul mot: "Connecté".');
    const latencyMs = Date.now() - start;

    return res.json({
      ok: true,
      model: result.model,
      latencyMs,
      reply: result.text?.trim() || 'Connecté',
    });
  } catch (err: any) {
    return res.status(500).json({ ok: false, error: err.message });
  }
});

// 0.1 Groq Connection & Model Tester Endpoint (Uses process.env.GROQ_API_KEY exclusively)
app.post('/api/groq/test', async (req, res) => {
  try {
    const keyToUse = process.env.GROQ_API_KEY || req.body?.apiKey;
    const model = req.body?.model || 'openai/gpt-oss-120b';

    if (!keyToUse) {
      return res.status(400).json({
        ok: false,
        error: 'Aucune variable GROQ_API_KEY configurée sur le serveur.',
      });
    }

    const resolvedModel = resolveGroqModel(model);
    const start = Date.now();

    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${keyToUse.trim()}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: resolvedModel,
        messages: [{ role: 'user', content: 'Réponds en un seul mot: "Connecté".' }],
        max_tokens: 20,
      }),
    });

    const latencyMs = Date.now() - start;

    if (response.ok) {
      const data = await response.json();
      const reply = data.choices?.[0]?.message?.content?.trim() || 'Connecté';
      return res.json({
        ok: true,
        model: resolvedModel,
        latencyMs,
        reply,
      });
    }

    const errData = await response.json().catch(() => null);
    const errMsg = errData?.error?.message || `Erreur HTTP ${response.status}`;
    return res.status(response.status).json({
      ok: false,
      status: response.status,
      error: errMsg,
      model: resolvedModel,
    });
  } catch (err: any) {
    return res.status(500).json({ ok: false, error: err.message });
  }
});

// 0.2 OpenRouter Connection & Model Tester Endpoint (Uses process.env.OPENROUTER_API_KEY exclusively)
app.post('/api/openrouter/test', async (req, res) => {
  try {
    const keyToUse = process.env.OPENROUTER_API_KEY || req.body?.apiKey;
    const model = req.body?.model || 'meta-llama/llama-3.3-70b-instruct:free';

    if (!keyToUse) {
      return res.status(400).json({
        ok: false,
        error: 'Aucune variable OPENROUTER_API_KEY configurée sur le serveur.',
      });
    }

    const resolvedModel = resolveOpenRouterModel(model);
    const start = Date.now();

    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${keyToUse.trim()}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://kaderbot.app',
        'X-Title': 'KADERBOT NOVA',
      },
      body: JSON.stringify({
        model: resolvedModel,
        messages: [{ role: 'user', content: 'Réponds en un seul mot: "Connecté".' }],
        max_tokens: 20,
      }),
    });

    const latencyMs = Date.now() - start;

    if (response.ok) {
      const data = await response.json();
      const reply = data.choices?.[0]?.message?.content?.trim() || 'Connecté';
      return res.json({
        ok: true,
        model: resolvedModel,
        latencyMs,
        reply,
      });
    }

    const errData = await response.json().catch(() => null);
    const errMsg = errData?.error?.message || `Erreur HTTP ${response.status}`;
    return res.status(response.status).json({
      ok: false,
      status: response.status,
      error: errMsg,
      model: resolvedModel,
    });
  } catch (err: any) {
    return res.status(500).json({ ok: false, error: err.message });
  }
});

// 1. Chat endpoint (Exclusively uses process.env.GEMINI_API_KEY, process.env.GROQ_API_KEY, process.env.OPENROUTER_API_KEY)
app.post('/api/chat', async (req, res) => {
  try {
    const {
      prompt,
      history = [],
      provider = 'gemini',
      groqModel = 'openai/gpt-oss-120b',
      openrouterModel = 'meta-llama/llama-3.3-70b-instruct:free',
      systemPrompt = DEFAULT_SYSTEM_PROMPT,
    } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt requis' });
    }

    const formattedHistory = history
      .map((h: { role: string; content: string }) => `${h.role === 'user' ? 'Utilisateur' : 'KADERBOT'}: ${h.content}`)
      .join('\n');
    const fullPrompt = `${systemPrompt}\n\nHistorique récent:\n${formattedHistory}\n\nUtilisateur: ${prompt}\nKADERBOT:`;

    // A. OpenRouter Provider (Exclusively using process.env.OPENROUTER_API_KEY)
    if (provider === 'openrouter') {
      const serverOpenRouterKey = process.env.OPENROUTER_API_KEY;

      if (!serverOpenRouterKey) {
        console.warn('Pas de OPENROUTER_API_KEY sur le serveur, bascule transparente sur Gemini (GEMINI_API_KEY)');
        const geminiRes = await callGeminiWithFallback(fullPrompt);
        return res.json({
          text: geminiRes.text,
          provider: 'gemini',
          model: geminiRes.model,
          isFallback: true,
          fallbackReason: 'Aucune variable OPENROUTER_API_KEY configurée sur le serveur',
        });
      }

      try {
        const { text, actualModel } = await callOpenRouterWithFallback(
          prompt,
          systemPrompt,
          serverOpenRouterKey,
          openrouterModel,
          history
        );
        return res.json({ text, provider: 'openrouter', model: actualModel });
      } catch (openRouterErr: any) {
        console.warn(`OpenRouter indisponible (${openRouterErr.message}), bascule de secours sur Gemini...`);
        const geminiRes = await callGeminiWithFallback(fullPrompt);
        return res.json({
          text: geminiRes.text,
          provider: 'gemini',
          model: geminiRes.model,
          isFallback: true,
          fallbackReason: openRouterErr.message,
        });
      }
    }

    // B. Groq Provider (Exclusively using process.env.GROQ_API_KEY)
    if (provider === 'groq') {
      const serverGroqKey = process.env.GROQ_API_KEY;

      if (!serverGroqKey) {
        console.warn('Pas de GROQ_API_KEY sur le serveur, bascule transparente sur Gemini (GEMINI_API_KEY)');
        const geminiRes = await callGeminiWithFallback(fullPrompt);
        return res.json({
          text: geminiRes.text,
          provider: 'gemini',
          model: geminiRes.model,
          isFallback: true,
          fallbackReason: 'Aucune variable GROQ_API_KEY configurée sur le serveur',
        });
      }

      try {
        const { text, actualModel } = await callGroqWithFallback(prompt, systemPrompt, serverGroqKey, groqModel, history);
        return res.json({ text, provider: 'groq', model: actualModel });
      } catch (groqErr: any) {
        console.warn(`Groq indisponible (${groqErr.message}), bascule de secours sur Gemini...`);
        const geminiRes = await callGeminiWithFallback(fullPrompt);
        return res.json({
          text: geminiRes.text,
          provider: 'gemini',
          model: geminiRes.model,
          isFallback: true,
          fallbackReason: groqErr.message,
        });
      }
    }

    // C. Default: Gemini 3.8 Flash (Exclusively using process.env.GEMINI_API_KEY via ai client)
    const geminiRes = await callGeminiWithFallback(fullPrompt);
    return res.json({ text: geminiRes.text, provider: 'gemini', model: geminiRes.model });
  } catch (error: any) {
    console.error('Erreur /api/chat:', error);
    return res.status(500).json({ error: error.message || 'Erreur serveur KADERBOT' });
  }
});

// 2. Ideas Generator endpoint (Exclusively server env keys)
app.post('/api/idees', async (req, res) => {
  try {
    const {
      theme,
      count = 5,
      style = 'creatif',
      styleDesc = '',
      provider = 'gemini',
      groqModel = 'openai/gpt-oss-120b',
      openrouterModel = 'meta-llama/llama-3.3-70b-instruct:free',
    } = req.body;

    const prompt = `Génère exactement ${count} idées courtes sur le thème : "${theme}". Style demandé: ${styleDesc || style}. Format obligatoire : une idée par ligne, numérotée de 1 à ${count}. Pas d'introduction ni de conclusion.`;

    if (provider === 'openrouter' && process.env.OPENROUTER_API_KEY) {
      try {
        const { text } = await callOpenRouterWithFallback(
          prompt,
          "Tu es un générateur d'idées créatif et concis.",
          process.env.OPENROUTER_API_KEY,
          openrouterModel
        );
        return res.json({ text });
      } catch (err) {
        console.warn('OpenRouter idees failed, falling back to Gemini');
      }
    }

    if (provider === 'groq' && process.env.GROQ_API_KEY) {
      try {
        const { text } = await callGroqWithFallback(prompt, "Tu es un générateur d'idées créatif et concis.", process.env.GROQ_API_KEY, groqModel);
        return res.json({ text });
      } catch (err) {
        console.warn('Groq idees failed, falling back to Gemini');
      }
    }

    const geminiRes = await callGeminiWithFallback(prompt, "Tu es un générateur d'idées créatif et percutant.");
    return res.json({ text: geminiRes.text });
  } catch (error: any) {
    console.error('Erreur /api/idees:', error);
    return res.status(500).json({ error: error.message });
  }
});

// 3. Translation endpoint (Exclusively server env keys)
app.post('/api/traduis', async (req, res) => {
  try {
    const {
      text,
      targetLang,
      provider = 'gemini',
      groqModel = 'openai/gpt-oss-120b',
      openrouterModel = 'meta-llama/llama-3.3-70b-instruct:free',
    } = req.body;
    const prompt = `Traduis le texte suivant en ${targetLang}. Réponds UNIQUEMENT par la traduction exacte, sans commentaire, guillemets ni introduction:\n\n${text}`;

    if (provider === 'openrouter' && process.env.OPENROUTER_API_KEY) {
      try {
        const { text: result } = await callOpenRouterWithFallback(
          prompt,
          'Tu es un traducteur professionnel expert.',
          process.env.OPENROUTER_API_KEY,
          openrouterModel
        );
        return res.json({ text: result });
      } catch (err) {
        console.warn('OpenRouter traduis failed, falling back to Gemini');
      }
    }

    if (provider === 'groq' && process.env.GROQ_API_KEY) {
      try {
        const { text: result } = await callGroqWithFallback(prompt, 'Tu es un traducteur professionnel expert.', process.env.GROQ_API_KEY, groqModel);
        return res.json({ text: result });
      } catch (err) {
        console.warn('Groq traduis failed, falling back to Gemini');
      }
    }

    const geminiRes = await callGeminiWithFallback(prompt, 'Tu es un traducteur polyglotte de précision. Tu retournes exclusivement le texte traduit.');
    return res.json({ text: geminiRes.text });
  } catch (error: any) {
    console.error('Erreur /api/traduis:', error);
    return res.status(500).json({ error: error.message });
  }
});

// 4. Corrector endpoint (Exclusively server env keys)
app.post('/api/corrige', async (req, res) => {
  try {
    const {
      text,
      provider = 'gemini',
      groqModel = 'openai/gpt-oss-120b',
      openrouterModel = 'meta-llama/llama-3.3-70b-instruct:free',
    } = req.body;
    const prompt = `Corrige les fautes d'orthographe, de grammaire et de ponctuation du texte suivant en gardant le sens et le ton. Réponds uniquement par le texte corrigé:\n\n${text}`;

    if (provider === 'openrouter' && process.env.OPENROUTER_API_KEY) {
      try {
        const { text: result } = await callOpenRouterWithFallback(
          prompt,
          'Tu es un correcteur professionnel.',
          process.env.OPENROUTER_API_KEY,
          openrouterModel
        );
        return res.json({ text: result });
      } catch (err) {
        console.warn('OpenRouter corrige failed, falling back to Gemini');
      }
    }

    if (provider === 'groq' && process.env.GROQ_API_KEY) {
      try {
        const { text: result } = await callGroqWithFallback(prompt, 'Tu es un correcteur professionnel.', process.env.GROQ_API_KEY, groqModel);
        return res.json({ text: result });
      } catch (err) {
        console.warn('Groq corrige failed, falling back to Gemini');
      }
    }

    const geminiRes = await callGeminiWithFallback(prompt, 'Tu es un correcteur linguistique d’élite. Tu renvoies exclusivement le texte corrigé.');
    return res.json({ text: geminiRes.text });
  } catch (error: any) {
    console.error('Erreur /api/corrige:', error);
    return res.status(500).json({ error: error.message });
  }
});

// 5. Summarizer endpoint (Exclusively server env keys)
app.post('/api/resume', async (req, res) => {
  try {
    const {
      text,
      provider = 'gemini',
      groqModel = 'openai/gpt-oss-120b',
      openrouterModel = 'meta-llama/llama-3.3-70b-instruct:free',
    } = req.body;
    const prompt = `Résume le texte suivant en 2 à 3 phrases claires, précises et directes. Réponds uniquement par le résumé:\n\n${text}`;

    if (provider === 'openrouter' && process.env.OPENROUTER_API_KEY) {
      try {
        const { text: result } = await callOpenRouterWithFallback(
          prompt,
          'Tu es un expert en synthèse documentaire.',
          process.env.OPENROUTER_API_KEY,
          openrouterModel
        );
        return res.json({ text: result });
      } catch (err) {
        console.warn('OpenRouter resume failed, falling back to Gemini');
      }
    }

    if (provider === 'groq' && process.env.GROQ_API_KEY) {
      try {
        const { text: result } = await callGroqWithFallback(prompt, 'Tu es un expert en synthèse documentaire.', process.env.GROQ_API_KEY, groqModel);
        return res.json({ text: result });
      } catch (err) {
        console.warn('Groq resume failed, falling back to Gemini');
      }
    }

    const geminiRes = await callGeminiWithFallback(prompt, 'Tu es un synthétiseur d’informations. Rédige un résumé dense et limpide.');
    return res.json({ text: geminiRes.text });
  } catch (error: any) {
    console.error('Erreur /api/resume:', error);
    return res.status(500).json({ error: error.message });
  }
});

// 6. Memory Persistence (Load & Save to JSON disk file)
app.get('/api/memory', requireAdmin, (req, res) => {
  try {
    if (fs.existsSync(MEMORY_FILE)) {
      const data = JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf-8'));
      return res.json(data);
    }
    return res.json({ memoire: {}, regles: {}, liens: {}, synonymes: {}, sessions: ['defaut'] });
  } catch (err: any) {
    console.error('Erreur lecture mémoire:', err);
    return res.status(500).json({ error: 'Erreur lecture stockage' });
  }
});

app.post('/api/memory/save', requireAdmin, (req, res) => {
  try {
    const { memoire, regles, liens, synonymes, sessions } = req.body;
    fs.writeFileSync(
      MEMORY_FILE,
      JSON.stringify({ memoire, regles, liens, synonymes, sessions, updatedAt: new Date().toISOString() }, null, 2),
      'utf-8'
    );
    return res.json({ success: true, savedAt: new Date().toISOString() });
  } catch (err: any) {
    console.error('Erreur sauvegarde mémoire:', err);
    return res.status(500).json({ error: 'Erreur écriture stockage' });
  }
});

// Vérification de session admin : l’URL ?admin=true seule ne donne aucun accès.
app.post('/api/admin/session', requireAdmin, (_req, res) => {
  return res.json({ ok: true });
});

// Endpoint de santé / ping de maintien d'activité (Render cron)
app.get('/api/health', (req, res) => {
  return res.json({ ok: true });
});

// Endpoint de rechargement à chaud de la mémoire depuis le disque
app.get('/api/memory/refresh', requireAdmin, (req, res) => {
  try {
    const data = readStorageFile();
    return res.json({
      ok: true,
      refreshedAt: new Date().toISOString(),
      data,
    });
  } catch (err: any) {
    console.error('Erreur /api/memory/refresh:', err);
    return res.status(500).json({ ok: false, error: err.message });
  }
});

app.get('/api/notes', requireAdmin, (_req, res) => {
  return res.json({ notes: readJsonArray<KaderbotNote>(NOTES_FILE) });
});

app.get('/api/agent/logs', requireAdmin, (_req, res) => {
  return res.json({ logs: readJsonArray<AgentActionLog>(ACTION_LOG_FILE).slice(-200).reverse() });
});

app.get('/api/calendar/events', requireAdmin, (_req, res) => {
  return res.json({ events: readJsonArray<KaderbotEvent>(EVENTS_FILE).slice(-500).reverse() });
});

// === 2. REGISTRE CENTRAL DES OUTILS ===
// Helper pour exécuter une recherche sur l'API Brave (Search ou News)
async function executeBraveSearch(query: string, isNews: boolean): Promise<string> {
  const apiKey = process.env.BRAVE_SEARCH_API_KEY?.trim() || BRAVE_API_KEY;
  if (!apiKey) {
    return "Clé BRAVE_SEARCH_API_KEY non configurée sur le serveur. Impossible d'effectuer la recherche web.";
  }

  if (!checkAndIncrementBraveQuota()) {
    return "Quota de recherche atteint pour aujourd'hui.";
  }

  const endpoint = isNews
    ? 'https://api.search.brave.com/res/v1/news/search'
    : 'https://api.search.brave.com/res/v1/web/search';

  const url = `${endpoint}?q=${encodeURIComponent(query)}&count=5&country=fr&search_lang=fr`;

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);

    const resp = await fetch(url, {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'X-Subscription-Token': apiKey,
      },
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (!resp.ok) {
      if (resp.status === 429) {
        return "Quota de recherche atteint pour aujourd'hui.";
      }
      return `Erreur Brave Search (HTTP ${resp.status} : ${resp.statusText}).`;
    }

    const data: any = await resp.json();
    const results = isNews ? (data.results || []) : (data.web?.results || []);

    if (!Array.isArray(results) || results.length === 0) {
      return `Aucun résultat ${isNews ? 'd’actualité' : 'web'} trouvé pour la requête : "${query}".`;
    }

    return results
      .slice(0, 5)
      .map((item: any, idx: number) => {
        const title = item.title || 'Sans titre';
        const itemUrl = item.url || '';
        const snippet = item.description || item.snippet || 'Pas de description';
        return `[${idx + 1}] ${title}\nURL: ${itemUrl}\nRésumé: ${snippet}`;
      })
      .join('\n\n');
  } catch (err: any) {
    if (err.name === 'AbortError') {
      return "Erreur Délai d'attente dépassé (timeout 6s) pour la recherche Brave.";
    }
    return `Erreur réseau lors de la recherche Brave : ${err.message}`;
  }
}

// === 4. IMPLÉMENTATION DES OUTILS ===
const TOOL_IMPLEMENTATIONS: Record<string, (args: any) => Promise<string>> = {
  search_web: async ({ query }: { query?: string }) => {
    if (!query?.trim()) return 'Requête de recherche vide.';
    return await executeBraveSearch(query.trim(), false);
  },

  search_news: async ({ query }: { query?: string }) => {
    if (!query?.trim()) return 'Requête d’actualité vide.';
    return await executeBraveSearch(query.trim(), true);
  },

  open_url: async ({ url }: { url?: string }) => {
    if (!url?.trim()) return 'URL manquante.';
    const cleanUrl = url.trim();
    const check = isUrlForbidden(cleanUrl);
    if (check.forbidden) {
      return `Accès refusé : ${check.reason || 'Domaine interdit'}`;
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6000);

      const resp = await fetch(cleanUrl, {
        signal: controller.signal,
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
          Accept:
            'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
          'Accept-Language': 'fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7',
          'Cache-Control': 'no-cache',
          Pragma: 'no-cache',
          'Sec-Ch-Ua': '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
          'Sec-Ch-Ua-Mobile': '?0',
          'Sec-Ch-Ua-Platform': '"Windows"',
          'Sec-Fetch-Dest': 'document',
          'Sec-Fetch-Mode': 'navigate',
          'Sec-Fetch-Site': 'none',
          'Sec-Fetch-User': '?1',
          'Upgrade-Insecure-Requests': '1',
        },
      });
      clearTimeout(timeoutId);

      if (!resp.ok) {
        if (resp.status === 403 || resp.status === 401) {
          return `Erreur HTTP ${resp.status} (Accès refusé / Anti-bot) : Le site bloque l'accès automatique. Ignore cette URL et poursuis avec les autres sources disponibles.`;
        }
        return `Erreur HTTP ${resp.status} (${resp.statusText}) lors de l'accès à la page. Ignore cette URL et passe aux autres sources.`;
      }

      let html = await resp.text();

      // Détection de protection Cloudflare / Captcha
      if (
        html.includes('cf-browser-verification') ||
        html.includes('Cloudflare Ray ID') ||
        html.includes('Attention Required! | Cloudflare') ||
        html.includes('Just a moment...')
      ) {
        return `Erreur HTTP 403 (Challenge Cloudflare / Anti-bot) : Cette page nécessite une vérification interactive de navigateur. Ignore cette source et passe à une autre.`;
      }

      // Retirer les balises script, style, nav, footer, header et leur contenu
      html = html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, ' ');
      html = html.replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, ' ');
      html = html.replace(/<nav\b[^<]*(?:(?!<\/nav>)<[^<]*)*<\/nav>/gi, ' ');
      html = html.replace(/<footer\b[^<]*(?:(?!<\/footer>)<[^<]*)*<\/footer>/gi, ' ');
      html = html.replace(/<header\b[^<]*(?:(?!<\/header>)<[^<]*)*<\/header>/gi, ' ');

      let text = html.replace(/<[^>]+>/g, ' ');
      text = text
        .replace(/&nbsp;/g, ' ')
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'");
      text = text.replace(/\s+/g, ' ').trim();

      if (!text || text.length < 50) {
        return 'La page web ne contient aucun contenu textuel exploitable. Passe à une autre source.';
      }
      return text.slice(0, 5000);
    } catch (err: any) {
      if (err.name === 'AbortError') {
        return "Délai d'attente dépassé (timeout 6s) pour ouvrir la page web. Ignore cette URL et passe aux autres.";
      }
      return `Erreur lors de la lecture de la page (${err.message}). Ignore cette source.`;
    }
  },

  memo_lookup: async ({ sujet }: { sujet?: string }) => {
    if (!sujet?.trim()) return 'Sujet manquant pour memo_lookup.';
    const storage = readStorageFile();
    const q = sujet.trim().toLowerCase();

    // 1. Chercher dans memoire
    let directMatches: any[] = [];
    if (storage.memoire[q]) {
      directMatches = storage.memoire[q];
    } else {
      const matchingKey = Object.keys(storage.memoire).find(
        k => k.toLowerCase() === q || k.toLowerCase().includes(q) || q.includes(k.toLowerCase())
      );
      if (matchingKey) {
        directMatches = storage.memoire[matchingKey];
      }
    }

    // 2. Chercher les liens
    const links = storage.liens[q] || [];

    // 3. Chercher les règles
    const rules = storage.regles[q] || [];

    if (directMatches.length === 0 && links.length === 0 && rules.length === 0) {
      return `Aucune information trouvée dans la mémoire locale pour le sujet "${sujet}".`;
    }

    let out = `Informations mémoire locale pour "${sujet}" :\n`;
    if (directMatches.length > 0) {
      out += directMatches.map((m: any, idx: number) => `- Définition/Fait [${idx + 1}] : ${m.def || m}`).join('\n') + '\n';
    }
    if (links.length > 0) {
      out += `- Héritage / Liens : ${links.join(', ')}\n`;
    }
    if (rules.length > 0) {
      out += `- Règles logiques : ${rules.map((r: any) => `${r.quant} sont ${r.prop}`).join('; ')}\n`;
    }
    return out.trim();
  },

  search_notes: async ({ query, limit = 10 }: { query?: string; limit?: number }) => {
    if (!query?.trim()) return 'Requête de notes vide.';
    const q = query.trim().toLowerCase();
    const notes = readJsonArray<KaderbotNote>(NOTES_FILE)
      .filter(note => `${note.title} ${note.body} ${note.tags.join(' ')}`.toLowerCase().includes(q))
      .slice(-(Math.min(Math.max(Number(limit) || 10, 1), 20)));
    if (notes.length === 0) return `Aucune note trouvée pour « ${query.trim()} ».`;
    return notes
      .map(note => `- ${note.title}${note.tags.length ? ` [${note.tags.join(', ')}]` : ''}\n  ${note.body.slice(0, 500)} (id: ${note.id})`)
      .join('\n');
  },

  list_events: async ({ start_iso, end_iso, limit = 20 }: { start_iso?: string; end_iso?: string; limit?: number }) => {
    const start = Date.parse(String(start_iso || ''));
    const end = Date.parse(String(end_iso || ''));
    if (Number.isNaN(start) || Number.isNaN(end)) return 'Dates ISO invalides.';
    const events = readJsonArray<KaderbotEvent>(EVENTS_FILE)
      .filter(event => Date.parse(event.startIso) < end && Date.parse(event.endIso) > start)
      .sort((a, b) => Date.parse(a.startIso) - Date.parse(b.startIso))
      .slice(0, Math.min(Math.max(Number(limit) || 20, 1), 50));
    if (events.length === 0) return 'Aucun événement trouvé dans cette période.';
    return events
      .map(event => `- ${event.title} : ${event.startIso} → ${event.endIso}${event.location ? ` | ${event.location}` : ''}`)
      .join('\n');
  },

  create_event: async ({ title, start_iso, end_iso, location, description }: { title?: string; start_iso?: string; end_iso?: string; location?: string; description?: string }) => {
    if (!title?.trim() || !start_iso || !end_iso) return 'Titre et dates requis pour l’événement.';
    const event: KaderbotEvent = {
      id: randomUUID(),
      title: title.trim(),
      startIso: new Date(start_iso).toISOString(),
      endIso: new Date(end_iso).toISOString(),
      location: location?.trim() || undefined,
      description: description?.trim() || undefined,
      createdAt: new Date().toISOString(),
    };
    const events = readJsonArray<KaderbotEvent>(EVENTS_FILE);
    events.push(event);
    writeJsonArray(EVENTS_FILE, events.slice(-1000));

    const toCalendarDate = (iso: string) => iso.replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');
    const calendarUrl = new URL('https://calendar.google.com/calendar/render');
    calendarUrl.searchParams.set('action', 'TEMPLATE');
    calendarUrl.searchParams.set('text', event.title);
    calendarUrl.searchParams.set('dates', `${toCalendarDate(event.startIso)}/${toCalendarDate(event.endIso)}`);
    if (event.location) calendarUrl.searchParams.set('location', event.location);
    if (event.description) calendarUrl.searchParams.set('details', event.description);
    return `Événement « ${event.title} » créé. Ajoute-le à ton agenda Google ici : ${calendarUrl.toString()}`;
  },

  create_note: async ({ title, body, tags = [] }: { title?: string; body?: string; tags?: string[] }) => {
    if (!title?.trim() || !body?.trim()) return 'Titre et contenu requis pour créer une note.';
    const now = new Date().toISOString();
    const note: KaderbotNote = {
      id: randomUUID(),
      title: title.trim(),
      body: body.trim(),
      tags: Array.isArray(tags) ? tags.map(tag => String(tag).trim()).filter(Boolean).slice(0, 20) : [],
      createdAt: now,
      updatedAt: now,
    };
    const notes = readJsonArray<KaderbotNote>(NOTES_FILE);
    notes.push(note);
    writeJsonArray(NOTES_FILE, notes.slice(-1000));
    return `Note « ${note.title} » créée avec succès.`;
  },

  send_message: async ({ channel, target, text }: { channel?: string; target?: string; text?: string }) => {
    if (!channel || !target?.trim() || !text?.trim()) return 'Canal, destinataire et texte requis.';
    if (channel === 'whatsapp') {
      const shareUrl = `https://wa.me/?text=${encodeURIComponent(text.trim())}`;
      return `Message WhatsApp préparé pour ${target.trim()} (aucun envoi automatique). Ouvre ce lien puis appuie sur Envoyer : ${shareUrl}`;
    }
    if (channel === 'telegram') {
      if (!TELEGRAM_BOT_TOKEN) return 'TELEGRAM_BOT_TOKEN n’est pas configuré sur Render.';
      if (!TELEGRAM_ALLOWED_CHAT_IDS.has(target.trim())) return `Le chat Telegram ${target.trim()} n’est pas autorisé par l’allowlist.`;
      const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: target.trim(), text: text.trim() }),
      });
      const payload: any = await response.json().catch(() => null);
      if (!response.ok || !payload?.ok) return `Échec Telegram : ${payload?.description || `HTTP ${response.status}`}`;
      return `Message Telegram envoyé à ${target.trim()}.`;
    }
    return 'L’envoi SMS n’est pas disponible depuis la Web App. Utilise un lien sms: ou un compagnon Android.';
  },

  memo_store: async ({ sujet, definition }: { sujet?: string; definition?: string }) => {
    if (!sujet?.trim() || !definition?.trim()) {
      return 'Sujet ou définition manquant pour memo_store.';
    }
    const storage = readStorageFile();
    const key = sujet.trim().toLowerCase();
    if (!storage.memoire[key]) {
      storage.memoire[key] = [];
    }

    const now = new Date().toISOString();
    storage.memoire[key].push({
      def: definition.trim(),
      poids: 1.0,
      hits: 1,
      source: 'agent',
      type: 'concept',
      created: now,
      last_used: now,
    });

    writeStorageFile(storage);
    return `Le fait "${sujet}" a été mémorisé avec succès dans la mémoire cognitive locale.`;
  },

  link_concepts: async ({ source, cible }: { source?: string; cible?: string }) => {
    if (!source?.trim() || !cible?.trim()) {
      return 'Source ou cible manquante pour link_concepts.';
    }
    const storage = readStorageFile();
    const sKey = source.trim().toLowerCase();
    const cKey = cible.trim().toLowerCase();

    if (!storage.liens[sKey]) {
      storage.liens[sKey] = [];
    }

    if (!storage.liens[sKey].includes(cKey)) {
      storage.liens[sKey].push(cKey);
      writeStorageFile(storage);
      return `Lien d'héritage enregistré : "${source}" est un/une "${cible}".`;
    }
    return `Le lien d'héritage "${source}" -> "${cible}" existait déjà.`;
  },

  ask_user: async ({ question }: { question?: string }) => {
    return `Question posée à l'utilisateur : ${question || 'Pouvez-vous préciser votre demande ?'}`;
  },
};

// === 3. LA BOUCLE AGENTIQUE ===
const AGENT_SYSTEM_PROMPT =
  'Tu es KADERBOT, un agent cognitif d’élite doté d’outils de recherche et d’analyse.\n' +
  'RÈGLES CRUCIALES :\n' +
  '(1) Vérifie toujours memo_lookup avant search_web si le sujet peut déjà être connu localement.\n' +
  '(2) Recherche sur le web via search_news ou search_web pour tout fait récent ou d’actualité.\n' +
  '(3) Si open_url renvoie une erreur (403, accès protégé, anti-bot ou timeout), ignore immédiatement cette source et passe aux autres URLs trouvées ou utilise les résumés de recherche.\n' +
  '(4) Si l’utilisateur demande "Continue" ou "continuer", utilise directement les informations déjà réunies pour produire la synthèse finale sans relancer de boucle superflue.\n' +
  '(5) Pour créer une note, utilise create_note ; pour chercher une note, utilise search_notes.\n' +
  '(6) Pour Telegram, utilise send_message avec channel=telegram et confirm=true ; une confirmation utilisateur sera demandée avant l’envoi.\n' +
  '(7) Pour WhatsApp, utilise send_message avec channel=whatsapp : cela prépare seulement un lien, sans envoi automatique.\n' +
  '(8) Pour l’agenda, utilise create_event ou list_events. Demande toujours des dates ISO 8601 avec fuseau horaire si elles sont ambiguës.\n' +
  '(9) Réponds toujours dans la langue de l’utilisateur, de façon concise et sans inventer.';

// Helper exécutant la boucle d'outils agentique pour un endpoint/modèle donné (Groq ou OpenRouter)
async function runToolLoopWithModel(
  endpoint: string,
  apiKey: string,
  model: string,
  providerLabel: string,
  userPrompt: string,
  history: Array<{ role: string; content: string }> = [],
  systemPrompt?: string,
  extraHeaders: Record<string, string> = {}
): Promise<{
  text?: string;
  provider: string;
  model: string;
  toolTrace: Array<{ tool: string; args?: any; status?: 'success' | 'error'; errorMsg?: string; resultSnippet?: string }>;
  awaitingUser?: boolean;
  question?: string;
  pendingAction?: PendingAgentAction;
}> {
  const isContinuePrompt = ['continue', 'continuer', 'poursuis', 'vas-y', 'go on', 'suite'].includes(userPrompt.trim().toLowerCase());
  const effectiveUserPrompt = isContinuePrompt
    ? "Poursuis l'analyse ou la recherche précédente et produis la synthèse finale claire et structurée en français."
    : userPrompt;

  const messages: any[] = [
    { role: 'system', content: systemPrompt || AGENT_SYSTEM_PROMPT },
    ...history,
    { role: 'user', content: effectiveUserPrompt },
  ];

  const toolTrace: Array<{ tool: string; args?: any; status?: 'success' | 'error'; errorMsg?: string; resultSnippet?: string }> = [];
  let lastText = '';
  const loopStartTime = Date.now();
  const MAX_LOOP_DURATION_MS = 25000; // 25s max pour éviter tout blocage réseau

  for (let i = 0; i < MAX_AGENT_ITERATIONS; i++) {
    // Si le temps limite est presque atteint, forcer la synthèse directe sans nouvel appel d'outil
    const elapsed = Date.now() - loopStartTime;
    if (elapsed > MAX_LOOP_DURATION_MS) {
      console.warn(`[AGENT TIMEOUT PREVENT] Limite de temps atteinte (${elapsed}ms), synthèse immédiate...`);
      break;
    }

    const fetchController = new AbortController();
    const fetchTimeoutId = setTimeout(() => fetchController.abort(), 14000);

    let response: Response;
    try {
      response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey.trim()}`,
          'Content-Type': 'application/json',
          ...extraHeaders,
        },
        body: JSON.stringify({
          model,
          messages,
          tools: AGENT_TOOLS,
          tool_choice: 'auto',
          temperature: 0.5,
        }),
        signal: fetchController.signal,
      });
    } catch (fetchErr: any) {
      clearTimeout(fetchTimeoutId);
      if (fetchErr.name === 'AbortError') {
        throw new Error(`[${model}] Délai d'attente API dépassé (14s)`);
      }
      throw fetchErr;
    }
    clearTimeout(fetchTimeoutId);

    if (!response.ok) {
      const errJson = await response.json().catch(() => null);
      const errMsg = errJson?.error?.message || `HTTP ${response.status}`;
      throw new Error(`[${model}] ${errMsg}`);
    }

    const data: any = await response.json();
    const assistantMsg = data.choices?.[0]?.message;

    if (!assistantMsg) {
      throw new Error(`[${model}] Réponse vide reçue`);
    }

    // Si la réponse contient des appels d'outils (tool_calls)
    if (assistantMsg.tool_calls && assistantMsg.tool_calls.length > 0) {
      messages.push(assistantMsg);

      for (const toolCall of assistantMsg.tool_calls) {
        const fnName = toolCall.function?.name;
        let parsedArgs: any = {};
        try {
          parsedArgs = JSON.parse(toolCall.function?.arguments || '{}');
        } catch (e: any) {
          console.warn(`Arguments d'outil invalides pour ${fnName}:`, toolCall.function?.arguments);
          parsedArgs = {};
        }

        const validationError = validateToolArguments(fnName, parsedArgs);
        if (validationError) {
          toolTrace.push({ tool: fnName, args: parsedArgs, status: 'error', errorMsg: validationError });
          messages.push({
            role: 'tool',
            tool_call_id: toolCall.id,
            content: `Erreur de validation : ${validationError}`,
          });
          continue;
        }

        // Cas ask_user : interruption de la boucle et retour direct
        if (fnName === 'ask_user') {
          toolTrace.push({ tool: fnName, args: parsedArgs, status: 'success' });
          return {
            awaitingUser: true,
            question: parsedArgs.question || 'Pouvez-vous préciser votre demande ?',
            provider: providerLabel,
            model,
            toolTrace,
          };
        }

        const policy = TOOL_POLICIES[fnName];
        const requiresConfirmation =
          policy?.confirmation === true ||
          (fnName === 'send_message' && parsedArgs.channel !== 'whatsapp');
        if (requiresConfirmation) {
          const pendingAction = createPendingAction(fnName, parsedArgs);
          toolTrace.push({
            tool: fnName,
            args: parsedArgs,
            status: 'success',
            resultSnippet: 'En attente de confirmation utilisateur',
          });
          return {
            awaitingUser: true,
            pendingAction,
            question: `Confirmation requise : ${pendingAction.summary}`,
            provider: providerLabel,
            model,
            toolTrace,
          };
        }

        let toolResultStr = '';
        let isError = false;
        let errorDetail = '';

        try {
          const handler = TOOL_IMPLEMENTATIONS[fnName];
          if (typeof handler === 'function') {
            toolResultStr = await handler(parsedArgs);
            if (
              toolResultStr.startsWith('Erreur') ||
              toolResultStr.startsWith('Impossible') ||
              toolResultStr.startsWith('Accès refusé') ||
              toolResultStr.includes('403') ||
              toolResultStr.includes("Délai d'attente dépassé")
            ) {
              isError = true;
              errorDetail = toolResultStr.slice(0, 160);
            }
          } else {
            toolResultStr = `Outil inconnu : ${fnName}`;
            isError = true;
            errorDetail = toolResultStr;
          }
        } catch (err: any) {
          toolResultStr = `Erreur lors de l'exécution de l'outil ${fnName} : ${err.message || 'Erreur inconnue'}`;
          isError = true;
          errorDetail = err.message || 'Erreur inconnue';
        }

        const snippet = toolResultStr.replace(/\s+/g, ' ').trim().slice(0, 120);

        toolTrace.push({
          tool: fnName,
          args: parsedArgs,
          status: isError ? 'error' : 'success',
          errorMsg: isError ? errorDetail : undefined,
          resultSnippet: snippet,
        });

        // Tronquer le résultat d'un outil pour l'injecter proprement dans la conversation
        let safeContent = (typeof toolResultStr === 'string' ? toolResultStr : JSON.stringify(toolResultStr)).slice(0, 5000);
        if (isError && fnName === 'open_url') {
          safeContent += ' [Note agent : Cette page est inaccessible ou protégée. Poursuis l’analyse avec une autre source ou résume avec les données déjà disponibles.]';
        }

        messages.push({
          role: 'tool',
          tool_call_id: toolCall.id,
          content: safeContent,
        });
      }

      continue;
    }

    // Réponse texte finale
    const content = assistantMsg.content?.trim() || '';
    lastText = content;
    return {
      text: content,
      provider: providerLabel,
      model,
      toolTrace,
    };
  }

  // Si la limite d'itérations ou de temps est atteinte, solliciter une dernière synthèse rapide
  if (!lastText && messages.length > 2) {
    try {
      const finalController = new AbortController();
      const finalTimeoutId = setTimeout(() => finalController.abort(), 9000);
      messages.push({
        role: 'user',
        content: 'Synthétise maintenant en 2 à 4 paragraphes clairs les informations recueillies jusqu’ici, sans appel d’outil supplémentaire.',
      });
      const synthResponse = await fetch(endpoint, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey.trim()}`,
          'Content-Type': 'application/json',
          ...extraHeaders,
        },
        body: JSON.stringify({
          model,
          messages,
          temperature: 0.5,
          max_tokens: 800,
        }),
        signal: finalController.signal,
      });
      clearTimeout(finalTimeoutId);
      if (synthResponse.ok) {
        const synthData: any = await synthResponse.json();
        const synthText = synthData.choices?.[0]?.message?.content?.trim();
        if (synthText) {
          return {
            text: synthText,
            provider: providerLabel,
            model,
            toolTrace,
          };
        }
      }
    } catch (e: any) {
      console.warn('Synthèse de secours non disponible:', e.message);
    }
  }

  return {
    text: lastText || 'Voici les informations réunies sur votre demande.',
    provider: providerLabel,
    model,
    toolTrace,
  };
}

// Cascade agentique complète : Groq 120B → Groq 20B → Gemini (sans tools) → OpenRouter Nemotron (avec tools)
async function runAgentLoop(
  userPrompt: string,
  history: Array<{ role: string; content: string }> = [],
  systemPrompt?: string
): Promise<{
  text?: string;
  provider: string;
  model?: string;
  toolTrace: Array<{ tool: string; args?: any }>;
  awaitingUser?: boolean;
  question?: string;
  isFallback?: boolean;
  fallbackReason?: string;
}> {
  const groqApiKey = process.env.GROQ_API_KEY?.trim();
  const openRouterApiKey = process.env.OPENROUTER_API_KEY?.trim();

  // === MAILLON 1 : Groq openai/gpt-oss-120b (avec tools) ===
  if (groqApiKey) {
    try {
      const res = await runToolLoopWithModel(
        'https://api.groq.com/openai/v1/chat/completions',
        groqApiKey,
        'openai/gpt-oss-120b',
        'groq-agent',
        userPrompt,
        history,
        systemPrompt
      );
      return res;
    } catch (err120: any) {
      console.warn(
        `[BASCULE AGENT] Maillon 1 (Groq openai/gpt-oss-120b) a échoué (cause: ${err120.message}). Bascule vers Maillon 2 (Groq openai/gpt-oss-20b)...`
      );
    }

    // === MAILLON 2 : Groq openai/gpt-oss-20b (avec tools) ===
    try {
      const res = await runToolLoopWithModel(
        'https://api.groq.com/openai/v1/chat/completions',
        groqApiKey,
        'openai/gpt-oss-20b',
        'groq-agent',
        userPrompt,
        history,
        systemPrompt
      );
      return {
        ...res,
        isFallback: true,
        fallbackReason: 'Groq openai/gpt-oss-120b a échoué, bascule sur openai/gpt-oss-20b',
      };
    } catch (err20: any) {
      console.warn(
        `[BASCULE AGENT] Maillon 2 (Groq openai/gpt-oss-20b) a échoué (cause: ${err20.message}). Bascule vers Maillon 3 (Gemini sans tools)...`
      );
    }
  } else {
    console.warn(
      '[BASCULE AGENT] Aucune variable GROQ_API_KEY configurée. Bascule vers Maillon 3 (Gemini sans tools)...'
    );
  }

  // === MAILLON 3 : Gemini (sans tools) ===
  try {
    const formattedHistory = history
      .map((h: { role: string; content: string }) => `${h.role === 'user' ? 'Utilisateur' : 'KADERBOT'}: ${h.content}`)
      .join('\n');
    const fullPrompt = `${systemPrompt || AGENT_SYSTEM_PROMPT}\n\nHistorique récent:\n${formattedHistory}\n\nUtilisateur: ${userPrompt}\nKADERBOT:`;

    const geminiRes = await callGeminiWithFallback(fullPrompt, systemPrompt || AGENT_SYSTEM_PROMPT);
    return {
      text: geminiRes.text,
      provider: 'gemini',
      model: geminiRes.model,
      toolTrace: [],
      isFallback: true,
      fallbackReason: 'Groq 120B et 20B indisponibles, bascule sur Gemini (sans tools)',
    };
  } catch (geminiErr: any) {
    if (openRouterApiKey) {
      console.warn(
        `[BASCULE AGENT] Maillon 3 (Gemini) a échoué (cause: ${geminiErr.message}). Bascule vers Maillon 4 (OpenRouter nvidia/nemotron-3.5-lightning:free)...`
      );
    } else {
      console.warn(
        `[BASCULE AGENT] Maillon 3 (Gemini) a échoué (cause: ${geminiErr.message}). Aucun maillon OpenRouter configuré.`
      );
    }
  }

  // === MAILLON 4 : OpenRouter 'nvidia/nemotron-3.5-lightning:free' (avec tools) ===
  if (openRouterApiKey) {
    try {
      const res = await runToolLoopWithModel(
        'https://openrouter.ai/api/v1/chat/completions',
        openRouterApiKey,
        'nvidia/nemotron-3.5-lightning:free',
        'openrouter-agent',
        userPrompt,
        history,
        systemPrompt,
        {
          'HTTP-Referer': 'https://kaderbot.app',
          'X-Title': 'KADERBOT NOVA',
        }
      );
      return {
        ...res,
        isFallback: true,
        fallbackReason: 'Groq et Gemini indisponibles, bascule sur OpenRouter nvidia/nemotron-3.5-lightning:free',
      };
    } catch (openRouterErr: any) {
      console.warn(
        `[BASCULE AGENT] Maillon 4 (OpenRouter nvidia/nemotron-3.5-lightning:free) a échoué (cause: ${openRouterErr.message}). Tous les maillons ont échoué.`
      );
    }
  }

  throw new Error('Tous les maillons de l’agent ont échoué (Groq gpt-oss-120b, Groq gpt-oss-20b, Gemini, OpenRouter Nemotron).');
}

// === ROUTER INTENTION (CHAT vs AGENT) ===
async function classifyIntentWithRouter(
  userPrompt: string,
  _history: Array<{ role: string; content: string }> = []
): Promise<'CHAT' | 'AGENT'> {
  const clean = userPrompt.trim().toLowerCase();
  // Si l'utilisateur demande de continuer ou poursuivre, c'est immédiatement une tâche AGENT
  if (['continue', 'continuer', 'poursuis', 'vas-y', 'go on', 'suite'].includes(clean)) {
    return 'AGENT';
  }

  const groqKey = process.env.GROQ_API_KEY?.trim();
  if (!groqKey) {
    // Si pas de clé Groq, basculer par défaut sur AGENT pour préserver la cascade
    return 'AGENT';
  }

  try {
    const classificationPrompt = `Réponds uniquement CHAT ou AGENT. AGENT si le message demande une recherche web, une info actuelle ou factuelle hors mémoire, ou apprendre/mémoriser un fait. CHAT sinon (salutations, conversation, opinions, création).

Message: "${userPrompt.replace(/"/g, '\\"')}"
Classification:`;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000);

    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${groqKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'openai/gpt-oss-20b',
        messages: [{ role: 'user', content: classificationPrompt }],
        max_tokens: 150,
        temperature: 0,
        reasoning_format: 'parsed',
      }),
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (!response.ok) {
      console.warn(`[ROUTER AGENT] Classification HTTP ${response.status}, défaut = AGENT`);
      return 'AGENT';
    }

    const data: any = await response.json();
    const msgObj = data.choices?.[0]?.message;
    const content = (msgObj?.content || '').trim().toUpperCase();
    const reasoning = (msgObj?.reasoning || '').trim().toUpperCase();

    if (content.includes('CHAT') || (!content && reasoning.slice(-80).includes('CHAT'))) {
      return 'CHAT';
    }
    return 'AGENT';
  } catch (err: any) {
    console.warn(`[ROUTER AGENT] Erreur classification (${err.message}), défaut = AGENT`);
    return 'AGENT';
  }
}

// === 5. ENDPOINT /api/agent ===
app.post('/api/agent', async (req, res) => {
  if (!checkAgentRateLimit(req)) {
    return res.status(429).json({ error: 'Limite atteinte : maximum 10 requêtes agentiques par minute.' });
  }
  try {
    const { prompt, history = [], systemPrompt } = req.body;
    if (!prompt || typeof prompt !== 'string') {
      return res.status(400).json({ error: 'Prompt requis' });
    }

    // 1. Classification d'intention (CHAT vs AGENT)
    const intent = await classifyIntentWithRouter(prompt, history);

    if (intent === 'CHAT') {
      const serverGroqKey = process.env.GROQ_API_KEY?.trim();
      if (serverGroqKey) {
        try {
          const chatRes = await callGroqWithFallback(
            prompt,
            systemPrompt || AGENT_SYSTEM_PROMPT,
            serverGroqKey,
            'openai/gpt-oss-120b',
            history
          );
          return res.json({
            text: chatRes.text,
            provider: 'groq-chat',
            model: chatRes.actualModel,
            routedTo: 'chat',
            toolTrace: [],
            isFallback: false,
          });
        } catch (chatErr: any) {
          console.warn(`[ROUTER AGENT] Groq chat direct a échoué (${chatErr.message}), bascule sur Gemini...`);
        }
      }

      // Fallback Gemini direct si Groq chat a échoué ou pas de clé
      try {
        const formattedHistory = history
          .map((h: { role: string; content: string }) => `${h.role === 'user' ? 'Utilisateur' : 'KADERBOT'}: ${h.content}`)
          .join('\n');
        const fullPrompt = `${systemPrompt || AGENT_SYSTEM_PROMPT}\n\nHistorique récent:\n${formattedHistory}\n\nUtilisateur: ${prompt}\nKADERBOT:`;
        const geminiRes = await callGeminiWithFallback(fullPrompt, systemPrompt || AGENT_SYSTEM_PROMPT);
        return res.json({
          text: geminiRes.text,
          provider: 'gemini',
          model: geminiRes.model,
          routedTo: 'chat',
          toolTrace: [],
          isFallback: true,
          fallbackReason: 'Groq indisponible pour le mode chat direct',
        });
      } catch (geminiErr: any) {
        console.warn(`[ROUTER AGENT] Gemini chat direct a échoué (${geminiErr.message}), exécution de la boucle agent complète...`);
      }
    }

    // 2. Si intention AGENT (ou échec de CHAT) : Exécute la cascade agentique complète
    const agentResult = await runAgentLoop(prompt, history, systemPrompt);
    return res.json({
      ...agentResult,
      routedTo: 'agent',
    });
  } catch (err: any) {
    console.error('Erreur critique /api/agent (tous les maillons ont échoué):', err);
    return res.status(500).json({ error: err.message || 'Erreur interne de l’agent' });
  }
});

// Décision explicite de l’utilisateur pour une action suspendue par la policy.
app.post('/api/agent/action', async (req, res) => {
  const { actionId, decision } = req.body || {};
  if (typeof actionId !== 'string' || !['approve', 'reject'].includes(decision)) {
    return res.status(400).json({ error: 'actionId et décision valide requis.' });
  }

  const action = pendingAgentActions.get(actionId);
  pendingAgentActions.delete(actionId);
  if (!action) return res.status(404).json({ error: 'Action introuvable ou déjà traitée.' });
  if (Date.parse(action.expiresAt) <= Date.now()) {
    appendActionLog({ tool: action.tool, args: action.args, status: 'expired', message: 'Confirmation expirée.' });
    return res.status(410).json({ error: 'Cette demande de confirmation a expiré.' });
  }

  if (decision === 'reject') {
    appendActionLog({ tool: action.tool, args: action.args, status: 'rejected', message: 'Refusée par l’utilisateur.' });
    return res.json({
      ok: true,
      text: `Action refusée : ${action.summary}`,
      provider: 'policy',
      toolTrace: [{ tool: action.tool, args: action.args, status: 'error', errorMsg: 'Refusée par l’utilisateur.' }],
    });
  }

  try {
    const handler = TOOL_IMPLEMENTATIONS[action.tool];
    if (typeof handler !== 'function') {
      return res.status(409).json({ error: `L’outil ${action.tool} n’est pas encore disponible.` });
    }
    const validationError = validateToolArguments(action.tool, action.args);
    if (validationError) return res.status(400).json({ error: validationError });
    const result = await handler(action.args);
    appendActionLog({ tool: action.tool, args: action.args, status: 'success', message: result });
    return res.json({
      ok: true,
      text: result,
      provider: 'policy',
      toolTrace: [{ tool: action.tool, args: action.args, status: 'success', resultSnippet: result.replace(/\s+/g, ' ').slice(0, 120) }],
    });
  } catch (err: any) {
    appendActionLog({ tool: action.tool, args: action.args, status: 'error', message: err.message || 'Échec de l’exécution.' });
    return res.status(500).json({ error: err.message || 'Échec de l’exécution de l’action.' });
  }
});

// Route de téléchargement de l’archive ZIP complète du projet web
app.get('/api/export-project-zip', (req, res) => {
  try {
    const zipPath = path.resolve(__dirname, '.aistudio/artifacts/brain/1e85614a-1a36-40c9-9d9d-04bf0651ef2e/kaderbot_projet_complet.zip');
    if (fs.existsSync(zipPath)) {
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="kaderbot-projet-web-complet.zip"');
      return res.sendFile(zipPath);
    } else {
      return res.status(404).json({ error: "L'archive ZIP n'est pas encore générée." });
    }
  } catch (err) {
    console.error('Erreur export zip:', err);
    return res.status(500).json({ error: 'Erreur lors du téléchargement du zip' });
  }
});

// 7. Python Pydroid 3 Export Script (Multi-mode: Console & Tkinter)
app.post('/api/export-pydroid', requireAdmin, (req, res) => {
  try {
    const {
      memoire = {},
      regles = {},
      liens = {},
      synonymes = {},
      groqApiKey = '',
      groqModel = 'openai/gpt-oss-120b',
      mode = 'auto', // 'auto' | 'console' | 'gui'
    } = req.body;
    const resolvedModel = resolveGroqModel(groqModel);

    // Encode memory and rules safely in Base64 so Python json.loads NEVER fails on null, true, false or quotes
    const b64Memoire = Buffer.from(JSON.stringify(memoire)).toString('base64');
    const b64Regles = Buffer.from(JSON.stringify(regles)).toString('base64');
    const b64Liens = Buffer.from(JSON.stringify(liens)).toString('base64');
    const b64Synonymes = Buffer.from(JSON.stringify(synonymes)).toString('base64');

    const defaultTargetMode = mode === 'console' ? 'CONSOLE' : mode === 'gui' ? 'GUI' : 'AUTO';

    const pythonScript = `# -*- coding: utf-8 -*-
"""
================================================================================
KADERBOT NOVA V14 - APPLICATION COMPLETE MULTI-MODE POUR PYDROID 3 (ANDROID)
================================================================================
Généré par KADERBOT NOVA Web Studio.
Ce script est conçu pour fonctionner SANS AUCUN CRASH sur Pydroid 3 (Android).

CARACTERISTIQUES :
- Mode hybride intelligent : Console interactive ultra-fluide ou Interface Tkinter
- Tolérance zéro crash : Si Tkinter n'est pas installé sur Android, bascule
  automatiquement sur la Console interactive
- Moteur cognitif complet : Déduction symbolique, causalité 'pourquoi',
  recherche floue (difflib), et association sémantique Question-Réponse
- Sauvegarde locale automatique dans 'kaderbot_memoire.json' sur votre téléphone
- Connectivité Groq Cloud ultra-rapide (${resolvedModel})
================================================================================
"""

import sys
import os
import json
import base64
import re
import difflib
import unicodedata
import threading
import urllib.request
import urllib.error
from datetime import datetime

# ==============================================================================
# CONFIGURATION & MODE D'EXECUTION
# ==============================================================================
# Modes possibles : 'CONSOLE' (recommandé Pydroid 3), 'GUI' (Tkinter), ou 'AUTO'
MODE_CIBLE = "${defaultTargetMode}"

API_KEY = "${groqApiKey}"
API_URL = "https://api.groq.com/openai/v1/chat/completions"
MODEL_GROQ = "${resolvedModel}"
GROQ_ACTIF = bool(API_KEY.strip())

SYSTEM_PROMPT = (
    "Tu es KADERBOT, un assistant cognitif sympa, concis et curieux. "
    "Tu réponds toujours en français, en 2 à 4 phrases maximum."
)

DATA_FILE = "kaderbot_memoire.json"

# ==============================================================================
# CHARGEMENT DES BASES DE CONNAISSANCES (DECODAGE BASE64 ULTRA-STABLE)
# ==============================================================================
def _decoder_base64_json(payload_b64):
    try:
        raw_bytes = base64.b64decode(payload_b64.encode('utf-8'))
        return json.loads(raw_bytes.decode('utf-8'))
    except Exception as e:
        print("[!] Erreur décodage interne:", e)
        return {}

memoire = _decoder_base64_json("${b64Memoire}")
regles = _decoder_base64_json("${b64Regles}")
liens = _decoder_base64_json("${b64Liens}")
synonymes = _decoder_base64_json("${b64Synonymes}")

contexte = []
historique_chat = []

# ==============================================================================
# PERSISTANCE LOCALE ANDROID
# ==============================================================================
def sauvegarder_donnees():
    try:
        data = {
            "memoire": memoire,
            "regles": regles,
            "liens": liens,
            "synonymes": synonymes,
            "updated_at": datetime.now().isoformat()
        }
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print("[!] Erreur sauvegarde locale :", e)
        return False

def charger_donnees():
    global memoire, regles, liens, synonymes
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                d = json.load(f)
                if "memoire" in d: memoire.update(d["memoire"])
                if "regles" in d: regles.update(d["regles"])
                if "liens" in d: liens.update(d["liens"])
                if "synonymes" in d: synonymes.update(d["synonymes"])
        except Exception as e:
            print("[!] Erreur chargement sauvegarde :", e)

charger_donnees()

# ==============================================================================
# OUTILS LINGUISTIQUES & EXTRACTION SEMANTIQUE
# ==============================================================================
MOTS_INTERROGATIFS_ET_VIDES = {
    'le', 'la', 'les', 'un', 'une', 'des', 'du', 'de', 'd', 'l',
    'ce', 'cet', 'cette', 'ces', 'mon', 'ton', 'son', 'ma', 'ta', 'sa',
    'qui', 'que', 'quoi', 'quel', 'quelle', 'quels', 'quelles',
    'comment', 'pourquoi', 'quand', 'est', 'sont', 'ete', 'etre',
    'avoir', 'fait', 'font', 'bonjour', 'salut', "s'il", 'te', 'plait'
}

def sans_accent(t):
    if not t: return ""
    return "".join(c for c in unicodedata.normalize("NFD", str(t)) if unicodedata.category(c) != "Mn").lower()

PONCT_SET = set(['?', '!', '.', ',', ';', ':', '"', chr(39), '(', ')', '[', ']', '{', '}', '-'])

def nettoyer_ponctuation(chaine):
    return "".join(" " if c in PONCT_SET else c for c in chaine)

def normaliser_question_cle(q):
    s = sans_accent(q)
    s = nettoyer_ponctuation(s)
    tokens = [w.strip() for w in s.split() if w.strip()]
    tokens_significatifs = [w for w in tokens if w not in MOTS_INTERROGATIFS_ET_VIDES and len(w) > 2]
    return " ".join(tokens_significatifs if tokens_significatifs else tokens)

def extraire_mots_cles(q):
    s = sans_accent(q)
    s = nettoyer_ponctuation(s)
    tokens = [w.strip() for w in s.split() if w.strip()]
    return set([w for w in tokens if w not in MOTS_INTERROGATIFS_ET_VIDES and len(w) > 2])

def rechercher_flou(texte, memoire_dict, regles_dict, seuil=0.72):
    t_clean = sans_accent(texte).strip()
    clefs = list(set(list(memoire_dict.keys()) + list(regles_dict.keys())))
    if not clefs: return None
    matches = difflib.get_close_matches(t_clean, [sans_accent(k) for k in clefs], n=1, cutoff=seuil)
    if matches:
        matched_norm = matches[0]
        for k in clefs:
            if sans_accent(k) == matched_norm:
                return k
    return None

def trouver_question_reponse(question, memoire_dict, seuil=0.70):
    if not question or not memoire_dict: return None
    q_norm = normaliser_question_cle(question)
    q_mots = extraire_mots_cles(question)
    if not q_norm and not q_mots: return None

    meilleur = None
    meilleur_score = 0.0

    for sujet, entries in memoire_dict.items():
        if not entries: continue
        entry = entries[0]
        is_qa = entry.get("type") == "question_reponse" or bool(entry.get("question_origine")) or " " in sujet
        if not is_qa: continue

        sujet_norm = normaliser_question_cle(entry.get("question_origine") or sujet)
        sujet_mots = set(entry.get("mots_cles") or list(extraire_mots_cles(sujet_norm)))

        if q_norm == sujet_norm:
            return {"sujet": sujet, "entry": entry, "score": 1.0}

        score = 0.0
        if q_mots and sujet_mots:
            intersection = q_mots.intersection(sujet_mots)
            union = q_mots.union(sujet_mots)
            score = len(intersection) / float(len(union)) if union else 0.0

        if score > meilleur_score:
            meilleur_score = score
            meilleur = {"sujet": sujet, "entry": entry, "score": score}

    if meilleur and meilleur_score >= seuil:
        return meilleur
    return None

def est_requete_definition(texte):
    t = sans_accent(texte).strip().rstrip("?.! ")
    prefixes = [
        "c'est quoi", "cest quoi", "qu'est ce que", "qu'est-ce que",
        "qu'est ce qu'", "qu'est-ce qu'", "qui est", "parle moi de",
        "parle-moi de", "definition de", "definir", "definis"
    ]
    for pref in prefixes:
        if t.startswith(pref):
            reste = t[len(pref):].strip()
            for art in ["le ", "la ", "les ", "un ", "une ", "des ", "l'", "d'"]:
                if reste.startswith(art):
                    reste = reste[len(art):].strip()
                    break
            mots = reste.split()
            if mots:
                return mots[0]
    mots_totaux = t.split()
    if len(mots_totaux) == 1:
        mot = mots_totaux[0]
        if len(mot) >= 3 and mot not in ["bonjour", "salut", "merci", "aide", "oui", "non"]:
            return mot
    elif len(mots_totaux) == 2 and mots_totaux[0] in ["le", "la", "les", "un", "une", "des", "ce", "cet", "cette"]:
        return mots_totaux[1]
    return None

def extraire_x(texte, memoire_dict, regles_dict, syn_dict, ctx_list):
    t = sans_accent(texte).strip().rstrip("?.! ")
    if "pourquoi" in t:
        idx = t.find("pourquoi")
        reste = t[idx + 8:].strip()
        for art in ["le ", "la ", "les ", "un ", "une ", "l'", "d'"]:
            if reste.startswith(art):
                reste = reste[len(art):].strip()
                break
        mots = reste.split()
        if mots:
            return mots[0]
    c_def = est_requete_definition(texte)
    if c_def:
        return c_def
    for p in ["il", "elle", "lui", "ceci", "cela"]:
        if p in t.split() and ctx_list:
            return ctx_list[-1]
    return None

def deduire_chaine(sujet, liens_dict, max_depth=6):
    chemin = [sujet]
    curr = sujet
    for _ in range(max_depth):
        parents = liens_dict.get(curr, [])
        if parents:
            curr = parents[0]
            chemin.append(curr)
        else:
            break
    return chemin

def repondre_pourquoi(texte, memoire_dict, regles_dict, liens_dict, syn_dict):
    sujet = extraire_x(texte, memoire_dict, regles_dict, syn_dict, contexte)
    if not sujet: return None
    chaine = deduire_chaine(sujet, liens_dict)
    for ancetre in chaine:
        if ancetre in regles_dict:
            for r in regles_dict[ancetre]:
                if r.get("quant") in ["tous", "chaque"]:
                    return f"Parce que {sujet} est un {ancetre}, et que tous les {ancetre}s {r.get('prop')}."
    return None

def apprendre_de_groq(question, reponse, memoire_dict):
    q_clean = sans_accent(question).strip()
    concept = est_requete_definition(question)
    if concept:
        sujet = concept
        prem_phrase = reponse.split(".")[0].strip()
        if len(prem_phrase) > 10:
            if sujet not in memoire_dict:
                memoire_dict[sujet] = []
            memoire_dict[sujet].insert(0, {
                "def": prem_phrase,
                "poids": 0.85,
                "hits": 1,
                "source": "groq",
                "type": "concept",
                "question_origine": question,
                "last_used": datetime.now().isoformat(),
                "created": datetime.now().isoformat()
            })
            sauvegarder_donnees()
            return sujet
    else:
        # Enregistrer Question + Réponse (Q&R)
        canonical_q = " ".join(nettoyer_ponctuation(q_clean).split())
        if len(canonical_q) > 4:
            mots_cles = list(extraire_mots_cles(question))
            if canonical_q not in memoire_dict:
                memoire_dict[canonical_q] = []
            memoire_dict[canonical_q].insert(0, {
                "def": reponse.strip(),
                "poids": 0.85,
                "hits": 1,
                "source": "groq",
                "type": "question_reponse",
                "mots_cles": mots_cles,
                "question_origine": question,
                "last_used": datetime.now().isoformat(),
                "created": datetime.now().isoformat()
            })
            sauvegarder_donnees()
            return canonical_q
    return None

# ==============================================================================
# INJECTION DE MEMOIRE CHIRURGICALE POUR LLM LOCAL (NOVA)
# ==============================================================================
def construire_prompt_contextuel_nova(question):
    """
    Construit le prompt chirurgical spécifiquement adapté pour le modèle local Nova.
    """
    qa_match = trouver_question_reponse(question, memoire)
    fait_connu = ""
    sujet_ref = ""

    if qa_match:
        fait_connu = qa_match["entry"].get("def", "")
        sujet_ref = qa_match["sujet"]
    else:
        x = extraire_x(question, memoire, regles, synonymes, contexte)
        if x and x in memoire:
            defs = [item["def"] for item in memoire[x]]
            fait_connu = " ; ".join(defs)
            sujet_ref = x

    if fait_connu:
        bloc_ctx = f"[FAIT VÉRIFIÉ EN MÉMOIRE LOCALE SUR '{sujet_ref.upper()}']\\n- {fait_connu}"
    else:
        bloc_ctx = "[MÉMOIRE LOCALE]\\nAucun fait spécifique stocké. Réponds avec fluidité et concision."

    return f"{SYSTEM_PROMPT}\\n\\n{bloc_ctx}\\n\\nUtilisateur: {question}\\nKADERBOT Nova:"

# ==============================================================================
# APPEL API GROQ
# ==============================================================================
def appeler_groq_sync(prompt, history_list):
    if not API_KEY.strip():
        return "Clé Groq non configurée. Ouvre les paramètres ou définis API_KEY."
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    for h in history_list[-4:]:
        messages.append(h)
    messages.append({"role": "user", "content": prompt})

    payload = json.dumps({
        "model": MODEL_GROQ,
        "messages": messages,
        "temperature": 0.7,
        "max_tokens": 600
    }).encode("utf-8")

    req = urllib.request.Request(
        API_URL,
        data=payload,
        headers={
            "Authorization": f"Bearer {API_KEY.strip()}",
            "Content-Type": "application/json",
            "User-Agent": "kaderbot-pydroid-v14"
        }
    )
    try:
        with urllib.request.urlopen(req, timeout=12) as response:
            res_data = json.loads(response.read().decode("utf-8"))
            return res_data["choices"][0]["message"]["content"].strip()
    except urllib.error.HTTPError as e:
        err_msg = e.read().decode("utf-8", errors="ignore")
        return f"Erreur Groq ({e.code}) : {err_msg}"
    except Exception as e:
        return f"Erreur connexion : {str(e)}"

# ==============================================================================
# DISPATCHER CENTRAL DE TRAITEMENT DES MESSAGES
# ==============================================================================
def traiter_message_texte(texte):
    """
    Traite un message et retourne un tuple : (type_source, message_reponse)
    type_source : 'LOCAL', 'DEDUCTION', 'GROQ', 'COMMANDE', 'SYSTEME'
    """
    txt = texte.strip()
    if not txt:
        return ("SYSTEME", "Message vide.")
    txt_lower = txt.lower()

    # 1. Commande retiens
    if txt_lower.startswith("retiens:"):
        corps = txt[8:].strip()
        if "=" in corps:
            s, d = [p.strip() for p in corps.split("=", 1)]
            s_clean = s.lower()
            if s_clean not in memoire: memoire[s_clean] = []
            memoire[s_clean].insert(0, {
                "def": d, "poids": 0.85, "hits": 1, "source": "manuel",
                "type": "concept",
                "last_used": datetime.now().isoformat(), "created": datetime.now().isoformat()
            })
            contexte.append(s_clean)
            sauvegarder_donnees()
            return ("COMMANDE", f"Fait retenu pour '{s_clean}' : {d}")
        return ("SYSTEME", "Format : retiens: sujet = définition")

    # 2. Commande lie
    if txt_lower.startswith("lie:"):
        corps = txt[4:].strip()
        if "->" in corps:
            src, dst = [p.strip().lower() for p in corps.split("->", 1)]
            if src not in liens: liens[src] = []
            if dst not in liens[src]: liens[src].append(dst)
            sauvegarder_donnees()
            return ("DEDUCTION", f"Lien d'héritage établi : {src} -> {dst}")
        return ("SYSTEME", "Format : lie: moineau -> oiseau")

    # 3. Commande lister
    if txt_lower.startswith("lister:"):
        cible = txt_lower[7:].strip()
        if cible == "memoire":
            keys = sorted(list(memoire.keys()))
            return ("SYSTEME", f"Mémoire ({len(keys)} sujets) :\\n" + ", ".join(keys[:35]))
        if cible == "regles":
            return ("SYSTEME", f"Règles ({len(regles)} catégories) :\\n" + ", ".join(regles.keys()))
        if cible == "liens":
            lignes = [f"{k} -> {', '.join(v)}" for k, v in liens.items()]
            return ("SYSTEME", "Liens d'héritage :\\n" + "\\n".join(lignes[:20]))

    # 4. Question causale 'pourquoi'
    if "pourquoi" in txt_lower:
        rep = repondre_pourquoi(txt, memoire, regles, liens, synonymes)
        if rep:
            return ("DEDUCTION", rep)

    # 5. Recherche Question-Réponse (Q&R enregistrée)
    qa_match = trouver_question_reponse(txt, memoire)
    if qa_match:
        entry = qa_match["entry"]
        rep = entry.get("def", "")
        return ("LOCAL", rep)

    # 6. Définition directe de concept
    x = extraire_x(txt, memoire, regles, synonymes, contexte)
    if x and x in memoire:
        contexte.append(x)
        defs = [item["def"] for item in memoire[x]]
        return ("LOCAL", f"{x.capitalize()} : " + " ; ".join(defs))

    # 7. Recherche floue Levenshtein (en cas de faute de frappe)
    flou = rechercher_flou(txt, memoire, regles)
    if flou and flou in memoire:
        contexte.append(flou)
        defs = [item["def"] for item in memoire[flou]]
        return ("LOCAL", f"(Tu voulais dire '{flou}' ?) : " + " ; ".join(defs))

    # 8. Fallback Groq Cloud
    if GROQ_ACTIF:
        rep = appeler_groq_sync(txt, historique_chat)
        historique_chat.append({"role": "user", "content": txt})
        historique_chat.append({"role": "assistant", "content": rep})
        apprendre_de_groq(txt, rep, memoire)
        return ("GROQ", rep)

    return ("LOCAL", f"Je ne connais pas encore ce sujet. Enseigne-le moi avec : retiens: {txt} = ...")

# ==============================================================================
# MODE 1 : INTERFACE CONSOLE / TERMINAL INTERACTIF (100% GARANTI SUR PYDROID 3)
# ==============================================================================
def lancer_mode_console():
    banner = f"""
================================================================================
          KADERBOT NOVA V14 - MOTEUR COGNITIF HYBRIDE (PYDROID 3)
================================================================================
[INFO] Mémoire locale chargée : {len(memoire)} entrées | {len(regles)} règles | {len(liens)} liens
[INFO] Modèle Groq actif : {"OUI (" + MODEL_GROQ + ")" if GROQ_ACTIF else "NON (Mode local seul)"}
--------------------------------------------------------------------------------
Commandes utiles :
  • Poser une question   : "c'est quoi le moineau ?", "pourquoi le faucon vole ?"
  • Apprendre un concept : "retiens: pigeon = oiseau urbain"
  • Créer un lien Is-A   : "lie: pigeon -> oiseau"
  • Inspecter la mémoire : "lister: memoire" ou "lister: regles"
  • Quitter              : "quitter" ou "exit"
================================================================================
"""
    print(banner)

    while True:
        try:
            user_input = input("\\n[Toi] > ").strip()
            if not user_input:
                continue

            if user_input.lower() in ["quitter", "exit", "quit", "q"]:
                print("\\n[KADERBOT] Au revoir et à bientôt ! Données sauvegardées.")
                sauvegarder_donnees()
                break

            source, reponse = traiter_message_texte(user_input)
            prefixe = f"[KADERBOT | {source}]"
            print(f"\\n{prefixe}\\n{reponse}")

        except (KeyboardInterrupt, EOFError):
            print("\\n\\n[KADERBOT] Interruption détectée. Données sauvegardées.")
            sauvegarder_donnees()
            break
        except Exception as err:
            print(f"[!] Erreur inattendue : {err}")

# ==============================================================================
# MODE 2 : INTERFACE GRAPHIQUE TKINTER (SI DISPONIBLE SUR ANDROID)
# ==============================================================================
def lancer_mode_tkinter():
    try:
        import tkinter as tk
        from tkinter import scrolledtext
    except Exception as e:
        print(f"[!] Tkinter n'est pas disponible dans ce Pydroid 3 ({e}).")
        print("[*] Bascule automatique sur la Console Interactive...")
        lancer_mode_console()
        return

    class KaderbotTkApp:
        def __init__(self, root):
            self.root = root
            self.root.title("KADERBOT NOVA V14 - Pydroid 3")
            self.root.geometry("480x760")
            self.root.configure(bg="#050508")

            # Bannière supérieure
            top_frame = tk.Frame(root, bg="#090B10", padx=10, pady=8)
            top_frame.pack(fill=tk.X)

            title_lbl = tk.Label(top_frame, text="KADERBOT NOVA V14", fg="#10A37F", bg="#090B10", font=("Arial", 13, "bold"))
            title_lbl.pack(side=tk.LEFT)

            self.stats_lbl = tk.Label(top_frame, text=f"{len(memoire)} faits", fg="#718096", bg="#090B10", font=("Arial", 9))
            self.stats_lbl.pack(side=tk.RIGHT)

            # Zone de discussion
            self.chat_area = scrolledtext.ScrolledText(root, bg="#0B0E17", fg="#E2E8F0", font=("Arial", 11), wrap=tk.WORD, bd=0, padx=10, pady=10)
            self.chat_area.pack(fill=tk.BOTH, expand=True, padx=8, pady=4)
            self.chat_area.tag_config("user", foreground="#63B3ED", justify="right")
            self.chat_area.tag_config("bot", foreground="#48BB78")
            self.chat_area.tag_config("system", foreground="#A0AEC0", font=("Arial", 9, "italic"))

            # Raccourcis tactiles
            pills_frame = tk.Frame(root, bg="#050508")
            pills_frame.pack(fill=tk.X, padx=8, pady=2)
            pills = [("C'est quoi...", "c'est quoi "), ("Pourquoi...", "pourquoi "), ("Retiens", "retiens: "), ("Mémoire", "lister: memoire")]
            for label, cmd in pills:
                btn = tk.Button(pills_frame, text=label, bg="#161822", fg="#CBD5E0", font=("Arial", 8), bd=1, relief=tk.FLAT, padx=6, pady=2,
                                command=lambda c=cmd: self.prefill(c))
                btn.pack(side=tk.LEFT, padx=2)

            # Zone d'envoi
            bottom_frame = tk.Frame(root, bg="#090B10", padx=8, pady=6)
            bottom_frame.pack(fill=tk.X)
            self.entry = tk.Entry(bottom_frame, bg="#161822", fg="#FFFFFF", insertbackground="#10A37F", font=("Arial", 11), bd=1, relief=tk.FLAT)
            self.entry.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=6, padx=(0, 6))
            self.entry.bind("<Return>", lambda e: self.envoyer())

            send_btn = tk.Button(bottom_frame, text="Envoyer", bg="#10A37F", fg="#FFFFFF", font=("Arial", 10, "bold"), bd=0, padx=12, pady=6, command=self.envoyer)
            send_btn.pack(side=tk.RIGHT)

            self.ajouter_message("KADERBOT", "Bonjour ! Je suis KADERBOT NOVA V14. Pose-moi une question ou utilise 'retiens: sujet = définition'.", "bot")

        def prefill(self, text):
            self.entry.delete(0, tk.END)
            self.entry.insert(0, text)
            self.entry.focus()

        def ajouter_message(self, auteur, texte, tag):
            self.chat_area.config(state=tk.NORMAL)
            if auteur:
                self.chat_area.insert(tk.END, f"\\n[{auteur}]\\n", tag)
            self.chat_area.insert(tk.END, f"{texte}\\n", tag)
            self.chat_area.see(tk.END)
            self.chat_area.config(state=tk.DISABLED)

        def envoyer(self):
            txt = self.entry.get().strip()
            if not txt: return
            self.entry.delete(0, tk.END)
            self.ajouter_message("Toi", txt, "user")
            source, rep = traiter_message_texte(txt)
            self.stats_lbl.config(text=f"{len(memoire)} faits")
            self.ajouter_message(f"KADERBOT | {source}", rep, "bot")

    try:
        root = tk.Tk()
        app = KaderbotTkApp(root)
        root.mainloop()
    except Exception as e:
        print(f"[!] Erreur au lancement de l'interface graphique Tkinter ({e}).")
        print("[*] Bascule automatique sur la Console Interactive...")
        lancer_mode_console()

# ==============================================================================
# POINT D'ENTREE PRINCIPAL
# ==============================================================================
if __name__ == "__main__":
    if MODE_CIBLE == "GUI":
        lancer_mode_tkinter()
    elif MODE_CIBLE == "CONSOLE":
        lancer_mode_console()
    else: # AUTO
        try:
            import tkinter as tk
            lancer_mode_tkinter()
        except Exception:
            lancer_mode_console()
`;

    const filename =
      mode === 'console'
        ? 'kaderbot_v14_pydroid_terminal.py'
        : mode === 'gui'
        ? 'kaderbot_v14_pydroid_tkinter.py'
        : 'kaderbot_v14_pydroid.py';

    res.setHeader('Content-Type', 'text/x-python');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    return res.send(pythonScript);
  } catch (err: any) {
    console.error('Erreur export pydroid:', err);
    return res.status(500).json({ error: err.message });
  }
});

// Vite middleware in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  const server = app.listen(PORT, HOST, () => {
    console.log(`🚀 Serveur KADERBOT NOVA opérationnel sur http://${HOST}:${PORT}`);
  });

  server.on('error', (err: any) => {
    console.error('Erreur serveur HTTP:', err);
  });
}

process.on('unhandledRejection', (reason) => {
  console.warn('Unhandled Rejection at:', reason);
});

process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception thrown:', err);
});

startServer().catch((err) => {
  console.error('Erreur démarrage serveur:', err);
});
